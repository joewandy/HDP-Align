/**
 * DataBlobTypeHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.ncbi.pubchem.holders;

public final class DataBlobTypeHolder implements javax.xml.rpc.holders.Holder {
    public gov.nih.nlm.ncbi.pubchem.DataBlobType value;

    public DataBlobTypeHolder() {
    }

    public DataBlobTypeHolder(gov.nih.nlm.ncbi.pubchem.DataBlobType value) {
        this.value = value;
    }

}
