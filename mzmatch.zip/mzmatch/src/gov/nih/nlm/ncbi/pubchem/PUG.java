/**
 * PUG.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package gov.nih.nlm.ncbi.pubchem;

public interface PUG extends javax.xml.rpc.Service {
    public java.lang.String getPUGSoapAddress();

    public gov.nih.nlm.ncbi.pubchem.PUGSoap getPUGSoap() throws javax.xml.rpc.ServiceException;

    public gov.nih.nlm.ncbi.pubchem.PUGSoap getPUGSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
