package com.joewandy.mzmatch.alignment;

import java.util.Comparator;

import com.joewandy.mzmatch.Feature;

public class FeatureIntensityComparator implements Comparator<Feature> {

	/*
	 * Sorts feature by intensity order, descending
	 * (non-Javadoc)
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int compare(Feature arg0, Feature arg1) {
		return -Double.compare(arg0.getIntensity(), arg1.getIntensity());
	}

}
