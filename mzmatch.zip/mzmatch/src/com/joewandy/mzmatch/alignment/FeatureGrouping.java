package com.joewandy.mzmatch.alignment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.joewandy.mzmatch.Feature;
import com.joewandy.mzmatch.FeatureGroup;

public class FeatureGrouping {

	private double rtTolerance;
	
	/**
	 * Creates a simple grouper
	 * @param dataList List of feature data to align
	 * @param massTolerance Mass tolerance in ppm
	 * @param rtTolerance Retention time tolerance in seconds
	 */
	public FeatureGrouping(double rtTolerance) {
		
		this.rtTolerance = rtTolerance;
				
	}
	
	public List<FeatureGroup> group(List<AlignmentFile> dataList) {

		for (AlignmentFile data : dataList) {
			// order features by intensity
			data.sortFeatures();
		}
		
		// the group ids must be unique across all input files 
		int groupId = 1;
		List<FeatureGroup> groups = new ArrayList<FeatureGroup>();
		for (AlignmentFile data : dataList) {

			System.out.print("Grouping " + data.getFilename() + " ");
			for (Feature feature : data.getFeatures()) {

				// process ungrouped features
				if (!feature.isGrouped()) {
					FeatureGroup group = new FeatureGroup(groupId);
					Set<Feature> nearbyFeatures = findNearbyFeatures(data, feature);
					if (!nearbyFeatures.isEmpty()) {
						group.addFeatures(nearbyFeatures);
					} 
					groupId++;
					groups.add(group);
				}
				
				if (groupId % 1000 == 0) {
					System.out.print(".");
				}
				
			}				
			System.out.println();
			
			int groupedCount = 0;
			int ungroupedCount = 0;
			for (Feature feature : data.getFeatures()) {
				// System.out.println(feature.getPeakID() + "\t" + feature.getGroup().getGroupId());
				if (feature.isGrouped()) {
					groupedCount++;
				} else {
					ungroupedCount++;
				}
			}			
			System.out.println("groupedCount = " + groupedCount);
			System.out.println("ungroupedCount = " + ungroupedCount);

		}
		
		return groups;
				
	}
	
	public void filterGroups(List<FeatureGroup> groups) {

		System.out.println("Filtering groups");
		Map<Integer, Integer> groupSize = new HashMap<Integer, Integer>();
		Iterator<FeatureGroup> it = groups.iterator();

		int removed = 0;
		while (it.hasNext()) {
			
			FeatureGroup group = it.next();

			// create a map to keep track of how many groups of certain sizes
			int memberCount = group.getFeatureCount();
			if (groupSize.get(memberCount) != null) {
				int newSize = groupSize.get(memberCount) + 1;
				groupSize.put(memberCount, newSize);
			} else {
				groupSize.put(memberCount, 1);
			}

			// remove groups below threshold
			if (group.getFeatureCount() <= FeatureXMLAlignment.GROUP_SIZE_THRESHOLD) {
				group.clearFeatures();
				it.remove();
				removed++;
			}
			
		}
		
		System.out.println(groupSize);
		System.out.println("Removed " + removed + " groups");
		System.out.println("Remaining " + groups.size() + " groups");
	}
		
	private Set<Feature> findNearbyFeatures(AlignmentFile data, Feature referenceFeature) {
		Set<Feature> nearbyFeatures = new HashSet<Feature>();
		// find matching feature
		Set<Feature> unmatched = data.getNextUngroupedFeatures(referenceFeature, this.rtTolerance);
		nearbyFeatures.addAll(unmatched);
		return nearbyFeatures;
	}
	
}
