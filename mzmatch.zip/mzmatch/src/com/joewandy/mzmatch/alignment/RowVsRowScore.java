package com.joewandy.mzmatch.alignment;

public class RowVsRowScore implements Comparable<RowVsRowScore> {

	private AlignmentRow reference;
	private AlignmentRow aligned;
	private double score;
	
	public RowVsRowScore(AlignmentRow reference, AlignmentRow aligned, 
			double mzTolerance, double rtTolerance) {
		
		this.reference = reference;
		this.aligned = aligned;

		double mzDiff = Math.abs(reference.getAverageMz() - aligned.getAverageMz());
		double rtDiff = Math.abs(reference.getAverageRt() - aligned.getAverageRt());
		
		double mzRatio = mzDiff/mzTolerance;
		double rtRatio = rtDiff/rtTolerance; 

		// lower is better
		this.score = mzRatio + rtRatio;
		
	}
	
	public AlignmentRow getReference() {
		return reference;
	}
	
	public AlignmentRow getAligned() {
		return aligned;
	}

	public double getScore() {
		return score;
	}

	@Override
	public int compareTo(RowVsRowScore object) {
		return Double.compare(this.score, object.getScore());
	}

}
