package com.joewandy.mzmatch.alignment.alignmentExp.dataGenerator;

import com.joewandy.mzmatch.alignment.alignmentExp.AlignmentData;

public interface AlignmentDataGenerator {

	public AlignmentData generate();
	
}
