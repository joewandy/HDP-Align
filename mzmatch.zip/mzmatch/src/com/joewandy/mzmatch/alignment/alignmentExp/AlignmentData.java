package com.joewandy.mzmatch.alignment.alignmentExp;

import java.util.List;

import com.joewandy.mzmatch.alignment.AlignmentFile;
import com.joewandy.mzmatch.alignment.GroundTruth;

public class AlignmentData {

	private List<AlignmentFile> alignmentDataList;
	private GroundTruth groundTruth;
	
	public AlignmentData(List<AlignmentFile> alignmentDataList,
			GroundTruth groundTruth) {
		this.alignmentDataList = alignmentDataList;
		this.groundTruth = groundTruth;
	}

	public List<AlignmentFile> getAlignmentDataList() {
		return alignmentDataList;
	}

	public GroundTruth getGroundTruth() {
		return groundTruth;
	}	
	
}
