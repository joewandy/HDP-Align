package com.joewandy.mzmatch.alignment.alignmentExp.dataGenerator;

import java.util.List;

import com.joewandy.mzmatch.alignment.AlignmentFile;
import com.joewandy.mzmatch.alignment.GroundTruth;
import com.joewandy.mzmatch.alignment.alignmentExp.AlignmentData;

public class ProteomicDataGenerator extends BaseDataGenerator implements AlignmentDataGenerator {

	@Override
	protected List<AlignmentFile> getAlignmentFiles() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected GroundTruth getGroundTruth() {
		// TODO Auto-generated method stub
		return null;
	}

}
