package com.joewandy.mzmatch.alignment.alignmentExp.dataGenerator;

import java.util.List;

import com.joewandy.mzmatch.alignment.AlignmentFile;
import com.joewandy.mzmatch.alignment.GroundTruth;
import com.joewandy.mzmatch.alignment.alignmentExp.AlignmentData;

public abstract class BaseDataGenerator implements AlignmentDataGenerator {

	public AlignmentData generate() {
		List<AlignmentFile> alignmentFiles = this.getAlignmentFiles();
		GroundTruth groundTruth = this.getGroundTruth();
		AlignmentData alignmentData = new AlignmentData(alignmentFiles, groundTruth);
		return alignmentData;
	}
	
	protected abstract List<AlignmentFile> getAlignmentFiles();
	
	protected abstract GroundTruth getGroundTruth();
	
}
