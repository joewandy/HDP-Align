/* Copyright (C) 2008, Groningen Bioinformatics Centre (http://gbic.biol.rug.nl/)
 * This file is part of mzmatch.
 * 
 * PeakML is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 * 
 * mzmatch is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with PeakML; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

package com.joewandy.mzmatch.alignment;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Collections;
import java.util.List;

import mzmatch.util.Tool;
import cmdline.CmdLineParser;

import com.joewandy.mzmatch.FeatureGroup;
import com.joewandy.mzmatch.alignment.alignmentExp.AlignmentData;
import com.joewandy.mzmatch.alignment.alignmentExp.dataGenerator.AlignmentDataGenerator;
import com.joewandy.mzmatch.alignment.alignmentExp.dataGenerator.AlignmentDataGeneratorFactory;
import com.joewandy.mzmatch.alignment.alignmentMethod.AlignmentMethod;
import com.joewandy.mzmatch.alignment.alignmentMethod.AlignmentMethodFactory;

public class FeatureXMLAlignment {
	
	public static final int ALIGNMENT_SIZE_THRESHOLD = 2;
	public static final int GROUP_SIZE_THRESHOLD = 0;
	// public static final int ALIGNMENT_SCORE_THRESHOLD = 20;
	
	public static void main(String args[]) {
		try {

			/*
			 * COMMAND LINE PARSING
			 */
			
			Tool.init();

			// parse the commandline options
			FeatureXMLAlignmentOptions options = new FeatureXMLAlignmentOptions();
			CmdLineParser cmdline = new CmdLineParser(options);

			// check whether we need to show the help
			cmdline.parse(args);
			if (options.help) {
				Tool.printHeader(System.out, FeatureXMLAlignmentOptions.APPLICATION, FeatureXMLAlignmentOptions.VERSION);
				cmdline.printUsage(System.out, "");
				return;
			}
			if (options.verbose) {
				Tool.printHeader(System.out, FeatureXMLAlignmentOptions.APPLICATION, FeatureXMLAlignmentOptions.VERSION);
				cmdline.printOptions();
			}

			/*
			 * LOAD FEATURES & GROUND TRUTH DATA
			 */
			
			AlignmentDataGenerator dataGenerator = AlignmentDataGeneratorFactory.getAlignmentDataGenerator(options);
			AlignmentData data = dataGenerator.generate();
			List<AlignmentFile> alignmentDataList = data.getAlignmentDataList();
			GroundTruth gt = data.getGroundTruth();
			
			/*
			 * NOISE & FILTERING
			 */
			
			// filtering to keep only features inside ground truth
			if (options.useGtFeaturesOnly) {
				System.out.println("Alignment based on ground-truth features only");
				for (AlignmentFile file : alignmentDataList) {
					file.filterFeatures(gt.getAllUniqueFeatures());
				}
			}
						
			/*
			 * GROUPING & ALIGNMENT
			 */

			// do grouping before aligning
			if (options.grouping) {
				FeatureGrouping grouping = new FeatureGrouping(options.groupingRtwindow);
				List<FeatureGroup> groups = grouping.group(alignmentDataList);
				grouping.filterGroups(groups); // remove groups that are too small
			}	
			
			// pick alignment method
			AlignmentMethod aligner = AlignmentMethodFactory.getAlignmentMethod(options, data);

			// setup some filters to prune alignment results later
			if (options.grouping) {
				AlignmentResultFilter sizeFilter = new SizeAlignmentResultFilter(FeatureXMLAlignment.ALIGNMENT_SIZE_THRESHOLD);
				aligner.addFilter(sizeFilter);
				AlignmentResultFilter graphFilter = new GraphAlignmentResultFilter(alignmentDataList, 
						options.graphFilter, options.th);
				aligner.addFilter(graphFilter);
			}
			
			// actually do the alignment now, filtering of alignment results also happen inside align()
			List<AlignmentRow> result = aligner.align();
			System.out.println("Total " + result.size() + " rows aligned");
			
			/*
			 * OUTPUT & EVALUATION
			 */
			
			PrintStream alignmentOutput = System.out;
			if (options.output != null) {
				System.out.println("Writing output");
				alignmentOutput = new PrintStream(new FileOutputStream(options.output));
				aligner.writeAlignmentResult(alignmentOutput);				
			}

			// do performance evaluation
			if (options.gt != null) {				
				gt.evaluate(Collections.unmodifiableList(result));				
			}
						
			// RetentionTimePrinter rtp = new RetentionTimePrinter();
			// rtp.printRt1(alignmentDataList.get(0), alignmentDataList.get(1));
			// rtp.printRt2(alignmentDataList.get(0), alignmentDataList.get(1), result);
			
		} catch (Exception e) {
			Tool.unexpectedError(e, FeatureXMLAlignmentOptions.APPLICATION);
		}
		
		System.exit(0);

	}

}