package com.joewandy.mzmatch.alignment;

import java.util.List;

public interface AlignmentResultFilter {

	public List<AlignmentRow> filter(List<AlignmentRow> rows);
	public String getLabel();
	
}
