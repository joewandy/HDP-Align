package com.joewandy.mzmatch.alignment;

import java.util.PriorityQueue;


public class TestPercentile {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		PriorityQueue<Double> pq = new PriorityQueue<Double>();
		double[] test = new double[10];
		for (int i = 0; i < test.length; i++) {
			test[i] = i+1;
			pq.add((double) i+1);
		}

		double th = 0.5;
		int n = (int) (th * test.length);
		int counter = 0;
		while (counter < n) {
			double elem = pq.poll();
			counter++;
			System.out.println(elem);
		}
		
	}

}
