package com.joewandy.mzmatch.alignment.alignmentMethod;

import java.util.List;

import net.sf.mzmine.data.PeakList;
import net.sf.mzmine.modules.MZmineProcessingModule;
import net.sf.mzmine.modules.peaklistmethods.alignment.join.JoinAlignerParameters;
import net.sf.mzmine.modules.peaklistmethods.alignment.ransac.RansacAlignerModule;
import net.sf.mzmine.modules.peaklistmethods.alignment.ransac.RansacAlignerParameters;
import net.sf.mzmine.parameters.ParameterSet;
import net.sf.mzmine.parameters.parametertypes.MZTolerance;
import net.sf.mzmine.parameters.parametertypes.MZToleranceParameter;
import net.sf.mzmine.parameters.parametertypes.PeakListsParameter;
import net.sf.mzmine.parameters.parametertypes.RTTolerance;
import net.sf.mzmine.parameters.parametertypes.RTToleranceParameter;
import net.sf.mzmine.taskcontrol.TaskListener;

import com.joewandy.mzmatch.alignment.AlignmentFile;

public class MzMineRansacAlignment extends MzMineAlignment implements
		AlignmentMethod, TaskListener {

	private MZmineProcessingModule alignerModule;

	/**
	 * Creates a simple join aligner
	 * 
	 * @param dataList
	 *            List of feature data to align
	 * @param massTolerance
	 *            Mass tolerance in ppm
	 * @param rtTolerance
	 *            Retention time tolerance in seconds
	 * @param rtDrift
	 */
	public MzMineRansacAlignment(List<AlignmentFile> dataList,
			double massTolerance, double rtTolerance) {

		super(dataList, massTolerance, rtTolerance);
		this.alignerModule = new RansacAlignerModule();
		
	}
	
	protected ParameterSet prepareParameterSet(PeakList[] peakLists) {
		
		ParameterSet params = new RansacAlignerParameters();

		// pre-initialise mass tolerance
		
		double toleranceMZ = 0;
		double tolerancePpm = 0;
		if (this.usePpm) {
			tolerancePpm = this.massTolerance;
		} else {
			toleranceMZ = this.massTolerance;
		}

		MZTolerance mzTolerance = new MZTolerance(toleranceMZ, tolerancePpm);
		MZToleranceParameter mzToleranceParam = params.getParameter(RansacAlignerParameters.MZTolerance);		
		mzToleranceParam.setValue(mzTolerance);
		
		// pre-initialise rt tolerance before & after parameters

		final boolean absolute = true;
		final double rtToleranceBeforeMinute = 30 / 60.0;
		final double rtToleranceAfterMinute = this.rtTolerance / 60.0;
		
		RTTolerance rtToleranceBefore = new RTTolerance(absolute, rtToleranceBeforeMinute);
		RTToleranceParameter rtToleranceBeforeParam = params.getParameter(RansacAlignerParameters.RTToleranceBefore);
		RTTolerance rtToleranceAfter = new RTTolerance(absolute, rtToleranceAfterMinute);
		RTToleranceParameter rtToleranceAfterParam = params.getParameter(RansacAlignerParameters.RTToleranceAfter);
		
		rtToleranceBeforeParam.setValue(rtToleranceBefore);
		rtToleranceAfterParam.setValue(rtToleranceAfter);
		
		// pre-initialise other ransac parameters
		
		final int ransacIteration = 15000;
		final double nMinPoints = 20/100.0;
		final double threshold = 4;

		params.getParameter(RansacAlignerParameters.Iterations).setValue(ransacIteration);
		params.getParameter(RansacAlignerParameters.NMinPoints).setValue(nMinPoints);
		params.getParameter(RansacAlignerParameters.Margin).setValue(threshold);
				
		// set the peaklist to align
		PeakListsParameter plp = params
				.getParameter(JoinAlignerParameters.peakLists);
		plp.setValue(peakLists);
		return params;

	}	
	
	protected MZmineProcessingModule getAlignerModule() {
		return this.alignerModule;
	}

}
