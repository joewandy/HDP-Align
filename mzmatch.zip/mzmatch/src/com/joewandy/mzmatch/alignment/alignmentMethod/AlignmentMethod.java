package com.joewandy.mzmatch.alignment.alignmentMethod;

import java.io.PrintStream;
import java.util.List;

import net.sf.mzmine.taskcontrol.TaskStatus;

import com.joewandy.mzmatch.alignment.AlignmentResultFilter;
import com.joewandy.mzmatch.alignment.AlignmentRow;

public interface AlignmentMethod {
	
	public List<AlignmentRow> align();

	public void addFilter(AlignmentResultFilter sizeFilter);

	public List<AlignmentRow> getAlignmentResult();
	
	public void writeAlignmentResult(PrintStream alignmentOutput);
		
}
