package com.joewandy.mzmatch.alignment.alignmentMethod;

import java.util.List;

import com.joewandy.mzmatch.alignment.AlignmentFile;
import com.joewandy.mzmatch.alignment.FeatureXMLAlignmentOptions;
import com.joewandy.mzmatch.alignment.alignmentExp.AlignmentData;

public class AlignmentMethodFactory {

	// a simple greedy alignment algorithm
	public static final String ALIGNMENT_METHOD_GREEDY = "greedy";

	// recreated version of mzMine Join aligner
	public static final String ALIGNMENT_METHOD_MZMINE_JOIN = "join";
	
	// calls mzMine RANSAC aligner
	public static final String ALIGNMENT_METHOD_MZMINE_RANSAC = "ransac";
	
	// calls SIMA alignment
	public static final String ALIGNMENT_METHOD_SIMA = "sima";

	// calls PAD/PASS alignment
	public static final String ALIGNMENT_METHOD_PASS = "pass";

	// calls SMFM alignment
	public static final String ALIGNMENT_METHOD_SMFM = "smfm";
	
	public static AlignmentMethod getAlignmentMethod(FeatureXMLAlignmentOptions options, AlignmentData data) {

		List<AlignmentFile> alignmentDataList = data.getAlignmentDataList();
		
		AlignmentMethod aligner = null; 
		if (AlignmentMethodFactory.ALIGNMENT_METHOD_GREEDY.equals(options.method)) {				
			aligner = new GreedyAlignment(alignmentDataList, options.alignmentPpm, options.alignmentRtwindow);
		} else if (AlignmentMethodFactory.ALIGNMENT_METHOD_MZMINE_RANSAC.equals(options.method)) {
			aligner = new MzMineRansacAlignment(alignmentDataList, options.alignmentPpm, options.alignmentRtwindow);
		} else if (AlignmentMethodFactory.ALIGNMENT_METHOD_MZMINE_JOIN.equals(options.method)) {
			aligner = new MzMineJoinAlignment(alignmentDataList, options.alignmentPpm, options.alignmentRtwindow);
		} else if (AlignmentMethodFactory.ALIGNMENT_METHOD_SIMA.equals(options.method)) {
			aligner = new SimaAlignment(alignmentDataList, options.alignmentPpm, options.alignmentRtwindow);
		} else if (AlignmentMethodFactory.ALIGNMENT_METHOD_PASS.equals(options.method)) {
		} else if (AlignmentMethodFactory.ALIGNMENT_METHOD_SMFM.equals(options.method)) {
		}
		
		return aligner;

	}
	
}
