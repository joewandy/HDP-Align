package com.joewandy.mzmatch.alignment;

import java.util.Random;

public class RandomGaussian {

	private Random fRandom = new Random();

	public double getGaussian(double aMean, double aVariance) {
		return aMean + fRandom.nextGaussian() * aVariance;
	}

	private static void log(Object aMsg) {
		System.out.println(String.valueOf(aMsg));
	}

	public static void main(String... aArgs) {
		RandomGaussian gaussian = new RandomGaussian();
		double MEAN = 100.0f;
		double VARIANCE = 5.0f;
		for (int idx = 1; idx <= 10; ++idx) {
			log("Generated : " + gaussian.getGaussian(MEAN, VARIANCE));
		}
	}
	
}
