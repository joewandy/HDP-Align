package com.joewandy.mzmatch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

import peakml.IPeak;
import peakml.IPeakSet;
import peakml.chemistry.PeriodicTable;

import com.joewandy.mzmatch.model.BinInterval;

public class BinConstructor {

	public List<BinInterval> constructBins(List<IPeakSet<IPeak>> peaksets,
			double ppm) {

		/*
		 * across all peaksets (input files), we want to create consistent bins
		 * first, find the minimum and maximum m/z across all peaksets
		 */
		Double[] maxMasses = new Double[peaksets.size()];
		Double[] minMasses = new Double[peaksets.size()];
		int i = 0;
		for (IPeakSet<IPeak> peaks : peaksets) {
			minMasses[i] = peaks.getMinMass();
			maxMasses[i] = peaks.getMaxMass();
			i++;
		}
		double minMass = Collections.min(Arrays.asList(minMasses));
		double maxMass = Collections.max(Arrays.asList(maxMasses));
		System.out.println("Min mass\t" + minMass);
		System.out.println("Max mass\t" + maxMass);

		/*
		 * Construct our overlapping bins starting from minMass to maxMass
		 * The bins are created in log space so they can be of equal size.
		 * 
		 * Created bins are inserted into a priority queue (instead of a list).
		 * Mostly just for convenience, so later we can poll and peek at the 
		 * head of the queue (the first bin, according to its start-end m/z values) 
		 * easily. Useful when finding which peaks fall into which bins.
		 */
		List<BinInterval> bins = new ArrayList<BinInterval>();
		int index = 0;

		double startMz = minMass;
		double delta = PeriodicTable.PPM(startMz, ppm);
		double endMz = startMz + delta;
		
		while (startMz < maxMass) {

			double startMzLog = Math.log(startMz);
			double endMzLog = Math.log(endMz);
			BinInterval newBin = new BinInterval(index, startMzLog, endMzLog);
			bins.add(newBin);
			index++;

			/* 
			 * shift startMz by half a bin interval,
			 * for the next overlapping bin ..
			 */
			startMz += delta/2;
			delta = PeriodicTable.PPM(startMz, ppm);
			endMz = startMz + delta;

		}

		System.out.println("First bin\t" + bins.get(0));
		System.out.println("Last bin\t" + bins.get(bins.size()-1));
		
		return bins;

	}

	public Map<Integer, BinInterval> binPeaks(PriorityQueue<BinInterval> binIntervalQueue, IPeakSet<IPeak> peaks, int sourcePeakSet) {
							
		/*
		 * Search for the first bin that fits a peak's m/z
		 * All peaks must belong to at least one bin. In fact,
		 * because a bin width is half a ppm, and they're overlapping,
		 * each peak should belong to 2 bins. Here, we just consider 
		 * the first bin that it fits into.
		 * 
		 * The inputs here are:
		 * - peakMassQueue is a queue of peaks, ordered by masses in ascending order
		 * - binIntervalQueue is a queue of bins, ordered by their intervals in ascending order
		 * 
		 * The output is:
		 * - binSizeQueue is a queue of bins containing peaks, ordered by how many peaks inside 
		 * in ascending order
		 * 
		 * We will remove peaks from peakMassQueue, allocate them to the appropriate bins from
		 * binIntervalQueue and insert the resulting bin containing peaks into binSizeQueue.
		 * 
		 */
		
		PriorityQueue<IPeak> peakMassQueue = new PriorityQueue<IPeak>(10, IPeak.sort_mass_ascending);
		peakMassQueue.addAll(peaks.getPeaks());
		
		// process from the bin with smallest start m/z onwards
		BinInterval currentBin = binIntervalQueue.poll();
		
		// process from the peak with smallest m/z onwards
		IPeak smallestPeak = peakMassQueue.poll();
		
		Set<BinInterval> result = new HashSet<BinInterval>();
		do {
			
			double logMass = Math.log(smallestPeak.getMass());
			
			// try to add peak to bin
			boolean canAdd = currentBin.addPeak(smallestPeak, sourcePeakSet);
			if (!canAdd) {
				
				/* 
				 * if the peak cannot fit into the bin anymore, we're done with the bin
				 * so, fetch the next bin in the queue
				 */
				currentBin = binIntervalQueue.poll();
				
			} else {

				// add current bin to result
				result.add(currentBin);
				
				/* 
				 * else if we can add to this bin, also check if we can add to the next (overlapping)
				 * bin. Use peek, not poll here.
				 */
				BinInterval nextBin = binIntervalQueue.peek();
				if (nextBin != null) {

					/* 
					 * if not ok, that means this peak doesn't fall into the next overlapping bin
					 * However, it should have fallen into the previous overlapping bin.
					 * If not, then it's the corner cases where binId = 0 or the last one.
					 */
					boolean ok = nextBin.addPeak(smallestPeak, sourcePeakSet);
					if (ok) {
						result.add(nextBin);						
					}

				}
				
				// move on to the next peak in the queue
				smallestPeak = peakMassQueue.poll();					

			}
			
		// while we still can retrieve some peak and there's some bin in the queue
		} while (smallestPeak != null);

		// store the final bin from the do-while above
		result.add(currentBin);					
				
		// remove everything except the non-empty bins
		Map<Integer, BinInterval> nonEmptyBins = new HashMap<Integer, BinInterval>();
		for(BinInterval bin : result) {
			if (!bin.isEmpty()) {
				nonEmptyBins.put(bin.getIndex(), bin);				
			}
		}
		return nonEmptyBins;
				
	}
	
	/**
	 * Compares bins first by their start intervals, next by their end intervals
	 * In ascending order
	 * @author joewandy
	 *
	 */
	public static class BinIntervalComparator implements Comparator<BinInterval> {
		@Override
		public int compare(BinInterval bin1, BinInterval bin2) {
			int i = Double.compare(bin1.getBinStart(), bin2.getBinStart());
			if (i != 0) {
				return i;
			}
			i = Double.compare(bin1.getBinEnd(), bin2.getBinEnd());
			return i;
		}
	}

	/**
	 * Compares bins by their size (no. of peaks assigned)
	 * In descending order
	 * @author joewandy
	 *
	 */
	public static class BinSizeComparator implements Comparator<BinInterval> {
		@Override
		public int compare(BinInterval bin1, BinInterval bin2) {
			// don't forget the minus sign here !
			return -Integer.compare(bin1.getSize(), bin2.getSize());
		}
	}
		
}