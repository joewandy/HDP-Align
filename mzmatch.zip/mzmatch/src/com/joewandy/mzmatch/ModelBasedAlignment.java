package com.joewandy.mzmatch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import mzmatch.ipeak.CombineTask;

import com.joewandy.mzmatch.model.AlignmentResult;
import com.joewandy.mzmatch.model.RelatedPeaksCluster;

import dk.ange.octave.OctaveEngine;
import dk.ange.octave.OctaveEngineFactory;
import dk.ange.octave.type.Octave;
import dk.ange.octave.type.OctaveDouble;
import dk.ange.octave.type.matrix.DoubleMatrix;

public class ModelBasedAlignment {

	private Map<Integer, RelatedPeaksCluster> relatedPeaksMap;
	private int numAlignmentClusters;
	private double[][] qs;
	private OctaveEngine octave;
	
	public ModelBasedAlignment(Map<Integer, RelatedPeaksCluster> relatedPeaksMap) {
		this.relatedPeaksMap = relatedPeaksMap;
		this.octave = new OctaveEngineFactory().getScriptEngine();
	}
	
	public List<AlignmentResult> align(int numAlignmentClusters) {
		par_em(numAlignmentClusters);		
		List<AlignmentResult> alignmentClusters = getAlignmentResults(numAlignmentClusters);		
		return alignmentClusters;
	}

	private List<AlignmentResult> getAlignmentResults(int numAlignmentClusters) {
		List<AlignmentResult> alignmentClusters = new ArrayList<AlignmentResult>();
		
		for (int k = 0; k < numAlignmentClusters; k++) {
			AlignmentResult align = new AlignmentResult(k);
			for (int n = 0; n < qs.length; n++) {
				RelatedPeaksCluster rpc = relatedPeaksMap.get(n);
				double prob = qs[n][k];
				align.addMember(rpc, prob);
			}
			alignmentClusters.add(align);
		}
		return alignmentClusters;
	}

	private void par_em(int K) {
		
		numAlignmentClusters = K;		
		octave.put("K", Octave.scalar(numAlignmentClusters));
		
		octave.eval("cd " + CombineTask.MATLAB_OUTPUT_PATH);
		octave.eval("load " + CombineTask.MATLAB_OUTPUT_FILENAME);
		
		// generic version for both matlab and octave, is quite slow in octave 
		// octave.eval("q = do_em(X, K);");
		
		// parallel version that can only run in octave
		octave.eval("pkg load general;");		
		octave.eval("q = par_em(X, K);");

		DoubleMatrix octaveMat = octave.get(OctaveDouble.class, "q");		
		octave.close();
		
		int[] sizes = octaveMat.getSize();
		int n = sizes[0];
		int k = sizes[1];

		// reshape 1d array of size 1 by (n*k) into a 2d array of size n by k
		double[] data = octaveMat.getData();
		double[][] reshaped = reshape(data, n, k);
		this.qs = reshaped;

	}

	private static double[][] reshape(double[] data, int nRows, int nCols) {
		double[][] reshaped = new double[nRows][nCols];
		for (int j = 0; j < nCols; j++) {
			for (int i = 0; i < nRows; i++) {
				int idx = i + nRows*j;
				reshaped[i][j] = data[idx];
			}
		}
		return reshaped;
	}
	
	public static void main(String[] args) {
		double[] data = new double[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		double[][] reshaped = reshape(data, 2, 5);
		System.out.println("data = " + Arrays.toString(data));
		System.out.println("reshaped = ");
		for (double[] row : reshaped) {
			System.out.println("\t" + Arrays.toString(row));		
		}
	}

}
