package mzmatch.ipeak;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List; 
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
import java.util.zip.GZIPOutputStream;

import mzmatch.ipeak.Combine.Options;
import mzmatch.ipeak.sort.CorrelationMeasure;
import peakml.Annotation;
import peakml.IPeak;
import peakml.IPeakSet;
import peakml.io.Header;
import peakml.io.ParseResult;
import peakml.io.peakml.PeakMLWriter;

import com.joewandy.mzmatch.CombinePeakComparator;
import com.joewandy.mzmatch.model.AlignmentEntry;

public class CombineFilterTask extends CombineBaseTask implements CombineTask {
 
	public void process(final Options options, Header header,
			Vector<IPeakSet<IPeak>> peaksets, ParseResult[] results,
			final Random random, CorrelationMeasure measure, float rangeMin,
			float rangeMax, int totalPeaks, OutputStream output) throws IOException, FileNotFoundException {
		
		List<Map<Integer, List<IPeak>>> clusterToPeaksMap = groupPeaks(
				options, header, peaksets, random, measure, rangeMin, rangeMax, CombineTask.CORR_GROUPING);
		
		List<IPeakSet<IPeak>> data = filterPeaksByGroups(clusterToPeaksMap, options.input, CombineTask.SELECT_N_CLUSTERS_FOR_PEAKS);				

		writePeaks(options, results, data);
		
	}

	protected void writePeaks(final Options options, ParseResult[] results,
			List<IPeakSet<IPeak>> data) throws FileNotFoundException,
			IOException {
		
		// write the result
		if (options.verbose) {
			System.out.println("Writing the results");
		}

		for (int i = 0; i < data.size(); i++) {
			IPeakSet<IPeak> ps = data.get(i);
			Set<IPeak> temp = new TreeSet<IPeak>(new CombinePeakComparator());
			for (IPeak p : ps) {
				p.setPatternID(-1);
				// p.removeAllAnnotations();
				// we're keeping the relation.id annotation here ... for use in model-based alignment next time
				p.removeAnnotation(Annotation.sourcePeakset);
				p.removeAnnotation(Annotation.peakId);
				temp.add(p);
			}
			Header h = results[i].header;
			OutputStream po = new FileOutputStream(options.input.get(i) + "." + i);
			PeakMLWriter.write(h, new ArrayList<IPeak>(temp), null, new GZIPOutputStream(po), null);					
			// PeakMLWriter.write(h, new ArrayList<IPeak>(temp), null, po, null);					
		}
		
	}
	
	/**
	 * Filter peaks by the top related peak groups, up to the specified limit
	 * @param clusterToPeaksMap
	 * @param fileNames
	 * @param limit
	 * @return
	 * @throws IOException
	 */
	protected List<IPeakSet<IPeak>> filterPeaksByGroups(
			List<Map<Integer, List<IPeak>>> clusterToPeaksMap, 
			List<String> fileNames, final int limit) throws IOException {
		
		// for all the input files
		int fileIdx = 0;		
		int allClusterIdx = 0;
		
		List<AlignmentEntry> allData = new ArrayList<AlignmentEntry>();
		List<IPeakSet<IPeak>> allPeaksets = new ArrayList<IPeakSet<IPeak>>();
		for (Map<Integer, List<IPeak>> eachFile : clusterToPeaksMap) {
			
			List<IPeakSet<IPeak>> filePeaks = new ArrayList<IPeakSet<IPeak>>();
			
			// sort by cluster size descending order
			List<List<IPeak>> sortedRelatedPeaks = new ArrayList<List<IPeak>>(eachFile.values());
			Collections.sort(sortedRelatedPeaks, new ListSizeComparator<IPeak>());

			int singleton = 0;
			int nonSingleton = 0;
			for (List<IPeak> relatedPeaks : sortedRelatedPeaks) {
				if (relatedPeaks.size() == 1) {
					singleton++;
				} else {
					nonSingleton++;
				}
			}
			// System.out.println("Singleton = " + singleton + ", nonSingleton = " + nonSingleton);
			
			int currentClusterCounter = 0;
			List<Integer> sizes = new ArrayList<Integer>();
			for (List<IPeak> relatedPeaks : sortedRelatedPeaks) {
			
				if (currentClusterCounter >= limit) {
					// System.out.println("Selected the top " + limit + " clusters of related peaks");
					break;
				}
				
				// System.out.println("Cluster #" + allClusterIdx + ": " + relatedPeaks.size() + " peaks");

				Set<IPeak> unique = new HashSet<IPeak>();
				for (IPeak p : relatedPeaks) {
					unique.add(p);
					AlignmentEntry matData = new AlignmentEntry(
							allClusterIdx,												// cluster id
							0,															// bin id 0 is unused
							fileIdx,													// peakset id (the input file)
							p.getPatternID(),											// peak id
							p.getAnnotation(Annotation.relationid).getValueAsInteger(),	// related peaks group id										
							p.getMass(),												// peak mass
							p.getRetentionTime(),										// peak retention time
							p.getIntensity()											// peak intensity
					);
					// System.out.println(matData);
					allData.add(matData);					
				}				
				
				IPeakSet<IPeak> peaks = new IPeakSet<IPeak>(new ArrayList<IPeak>(unique));
				// System.out.println("Total peaks in this cluster: " + peaks.size());
				sizes.add(peaks.size());

				filePeaks.add(peaks);
				currentClusterCounter++;
				allClusterIdx++;

			}
			// System.out.println();
			// System.out.println("sizes = " + sizes + ";");
			fileIdx++;

			IPeakSet<IPeak> packed = new IPeakSet(filePeaks);
			IPeakSet<IPeak> related = new IPeakSet<IPeak>(unpack(packed));
			allPeaksets.add(related);
			
		}
						
		return allPeaksets;
		
	}	
	
}