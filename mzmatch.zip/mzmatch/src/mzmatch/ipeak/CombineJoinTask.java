package mzmatch.ipeak;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Vector;
import java.util.zip.GZIPOutputStream;

import mzmatch.ipeak.Combine.Options;
import mzmatch.ipeak.CombineBaseTask.PeakMatchCompare;
import mzmatch.ipeak.sort.CorrelationMeasure;
import peakml.Annotation;
import peakml.IPeak;
import peakml.IPeakSet;
import peakml.IPeak.MatchCompare;
import peakml.chemistry.PeriodicTable;
import peakml.io.Header;
import peakml.io.ParseResult;
import peakml.io.peakml.PeakMLWriter;
import peakml.math.Signal;

import com.joewandy.mzmatch.model.AlignmentEntry;

public class CombineJoinTask extends CombineBaseTask implements CombineTask {

	public void process(final Options options, Header header,
			Vector<IPeakSet<IPeak>> peaksets, ParseResult[] results,
			final Random random, CorrelationMeasure measure, float rangeMin,
			float rangeMax, int totalPeaks, OutputStream output) throws IOException, FileNotFoundException {

		// greedily match peaks across files
		List<IPeakSet<IPeak>> matches = match(peaksets, options.ppm, new PeakMatchCompare<IPeak>(options.rtwindow));						
		
		// unpack potential sub-peaksets
		List<IPeakSet<IPeak>> data = new ArrayList<IPeakSet<IPeak>>();
		int alignmentClusterIdx = 0;
		
		int peaksInThreeClusters = 0;
		int peaksInTwoClusters = 0;

		List<double[]> intensesAll = new ArrayList<double[]>();
		
		for (IPeakSet<IPeak> match : matches) {
								
			// debugging only
			IPeakSet<IPeak> alignmentCluster = new IPeakSet<IPeak>(unpack(match));
			
			int size = alignmentCluster.size();
			System.out.println("Cluster #" + alignmentClusterIdx + " has " + size + " peaks");
			double intenses[] = new double[peaksets.size()];
			for (IPeak p : alignmentCluster) {
			
				if (size == 2) {
					peaksInTwoClusters++;
				} else if (size == 3) {
					peaksInThreeClusters++;
				}
				
				int sourcePeakset = p.getAnnotation(Annotation.sourcePeakset).getValueAsInteger();
				Annotation relationIdAnnotation = p.getAnnotation(Annotation.relationid);
				int groupId = 0;
				if (relationIdAnnotation != null) {
					groupId = relationIdAnnotation.getValueAsInteger();
				}
				AlignmentEntry matData = new AlignmentEntry(
						alignmentClusterIdx,												// cluster id
						0,																	// bin id
						sourcePeakset,														// peakset id (the input file)
						p.getAnnotation(Annotation.peakId).getValueAsInteger(),				// peak id
						groupId,				// related peaks group id			
						p.getMass(),			// peak mass
						p.getRetentionTime(),	// peak retention time
						p.getIntensity()		// peak intensity
				);
				System.out.println(matData);
				if (size == 2) {
					intenses[sourcePeakset] = p.getIntensity();							
				}
				
			}						
			
			alignmentClusterIdx++;
			data.add(alignmentCluster);
			if (size == 2) {
				intensesAll.add(intenses);
			}
			
		}

		evaluateResult(peaksets.size(), totalPeaks, peaksInThreeClusters,
				peaksInTwoClusters, intensesAll);
		
		// write the result
		if (options.verbose)
			System.out.println("Writing the results");
		PeakMLWriter.write(header, data, null, new GZIPOutputStream(output), null);
		
	}
	
	/**
	 * General function for matching peaks together. The function works by minimizing the
	 * distance between two peaks as calculated by the pluggable MatchCompare instance. The
	 * peaks are passed as peaksets (i.e. the peaks of one set are collected in a single
	 * peakset). The vector contains all the datasets and will treated as such.
	 * <p />
	 * Keep track of where a peak came from with the measurementid found in each peak.
	 * 
	 * @param samples		The samples to compare.
	 * @param ppm			The parts-per-milion the masses can differ at most.
	 * @param compare		The comparator for comparing two peaks.
	 * @return				A vector with all the matched peaks.
	 */
	@SuppressWarnings("unchecked")
	public static Vector<IPeakSet<IPeak>> match(List<IPeakSet<IPeak>> samples, double ppm, MatchCompare compare)
	{
		final int UNPROCESSED = 0;
		final int MATCHED = 1;
		
		// create a vector of mass-chromatogram sets sorted on intensity
		Vector<Vector<IPeak>> masschromatogramdata = new Vector<Vector<IPeak>>();
		for (IPeakSet<? extends IPeak> sample : samples)
		{
			// assign the UNPROCESSED id to all the mass chromatograms
			sample.resetPatternIDs(UNPROCESSED);
						
			// make a copy of the peak-vector and sort ascending
			Vector<IPeak> masschromatograms = new Vector<IPeak>(sample.getPeaks());
			Collections.sort(masschromatograms, IPeak.sort_intensity_descending);
			
			// add the new vector to the list
			masschromatogramdata.add(masschromatograms);
		}
		
		// create an array with the current index for each sorted mass-chromatogram set
		int nrsamples = samples.size();
		int indices[] = new int[nrsamples];
		for (int i=0; i<nrsamples; ++i)
			indices[i] = 0;
		
		// try to match everything
		Vector<IPeakSet<IPeak>> matchdata = new Vector<IPeakSet<IPeak>>();
		while (true)
		{
			// find the most intense mass chromatogram
			int refid = -1;
			double refintensity = -1;
			IPeak refmasschromatogram = null;
			for (int id=0; id<nrsamples; ++id)
			{
				Vector<IPeak> masschromatograms = masschromatogramdata.get(id);
				
				// locate the current index of this sample (e.g. the first unmatched mass chromatogram)
				while (indices[id]<masschromatograms.size() && masschromatograms.get(indices[id]).getPatternID()!=UNPROCESSED)
					indices[id]++;
				if (indices[id] == masschromatograms.size())
					continue;
				
				// 
				// TODO check if valid ??
				IPeak masschromatogram = masschromatograms.get(indices[id]);
				if (refid==-1 || masschromatogram.getIntensity()>refintensity)
				{
					refid = id;
					refintensity = masschromatogram.getIntensity();
					refmasschromatogram = masschromatogram;
				}
			}
			
			// check whether everything has been processed
			if (refmasschromatogram == null)
				break;
			
			// mark the reference mass chromatogram as matched
			refmasschromatogram.setPatternID(MATCHED);
			
			// retrieve the properties of the reference
			double refmass = refmasschromatogram.getMass();
			double refdelta = PeriodicTable.PPM(refmass, ppm);
			
			// match this mass chromatogram to those in the other samples
			Vector<IPeak> matches = new Vector<IPeak>();
			for (int id=0; id<nrsamples; ++id)
			{
				if (id == refid)
				{
					matches.add(refmasschromatogram);
					continue;
				}
				
				// retrieve the spectrum
				IPeakSet<? extends IPeak> masschromatograms = samples.get(id);
				
				// retrieve all the masschromatograms with ~ equal mass as the current refmasschromatogram
				Vector<? extends IPeak> neighbourhood = masschromatograms.getPeaksOfMass(refmass, refdelta);
				
				// select the closest in scan ??
				double bestdistance = -1;
				IPeak bestmasschromatogram = null;
				for (IPeak masschromatogram : neighbourhood)
				{
					if (masschromatogram.getPatternID() != UNPROCESSED)
						continue;
					
					double distance = compare.distance(refmasschromatogram, masschromatogram);
					if (distance < 0)
						continue;
					
					if (bestmasschromatogram==null || distance<bestdistance)
					{
						bestdistance = distance;
						bestmasschromatogram = masschromatogram;
					}
				}
				
				if (bestmasschromatogram != null)
				{
					matches.add(bestmasschromatogram);
					bestmasschromatogram.setPatternID(MATCHED);
				}
			}
			
			matchdata.add(new IPeakSet<IPeak>(matches));
		}
		
		return matchdata;
	}
	
}
