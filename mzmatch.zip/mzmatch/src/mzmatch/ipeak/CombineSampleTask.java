package mzmatch.ipeak;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.PriorityQueue;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

import mzmatch.ipeak.Combine.Options;
import mzmatch.ipeak.sort.CorrelationMeasure;
import mzmatch.ipeak.sort.ShapeCorrelations;
import no.uib.cipr.matrix.MatrixEntry;
import no.uib.cipr.matrix.sparse.FlexCompRowMatrix;
import peakml.Annotation;
import peakml.IPeak;
import peakml.IPeakSet;
import peakml.io.Header;
import peakml.io.ParseResult;

import com.jmatio.io.MatFileWriter;
import com.jmatio.types.MLArray;
import com.jmatio.types.MLDouble;
import com.jmatio.types.MLSparse;
import com.joewandy.mzmatch.BinConstructor;
import com.joewandy.mzmatch.ModelBasedAlignment;
import com.joewandy.mzmatch.model.AlignmentResult;
import com.joewandy.mzmatch.model.BinData;
import com.joewandy.mzmatch.model.BinInterval;
import com.joewandy.mzmatch.model.AlignmentEntry;
import com.joewandy.mzmatch.model.RelatedPeaksCluster;

public class CombineSampleTask extends CombineBaseTask implements CombineTask {

	public void process(final Options options, Header header,
			Vector<IPeakSet<IPeak>> peaksets, ParseResult[] results,
			final Random random, CorrelationMeasure measure, float rangeMin,
			float rangeMax, int totalPeaks, OutputStream output) throws IOException, FileNotFoundException {

		List<AlignmentResult> alignmentClusters = binAndAlign(options, header,
				peaksets, random, measure, rangeMin, rangeMax);
		
		System.out.println();
		System.out.println("===========================================");
		System.out.println("MODEL-BASED ALIGNMENT");
		System.out.println("===========================================");
		System.out.println();
		
		int alignmentClusterIdx = 0;
		int peaksInThreeClusters = 0;
		int peaksInTwoClusters = 0;
		
		List<double[]> intensesAll = new ArrayList<double[]>();

		for (AlignmentResult align : alignmentClusters) {

			System.out.println();
			System.out.println(align);				

			List<IPeakSet<IPeak>> matches = matchPeaksInClusters(options,
					peaksets, align);						
			
			// print out the alignment results ...
			for (IPeakSet<IPeak> match : matches) {
				
				// debugging only
				IPeakSet<IPeak> alignmentCluster = new IPeakSet<IPeak>(unpack(match));
				
				int size = alignmentCluster.size();	
				if (size == 1) {
					continue;
				}
				
				System.out.println("Cluster #" + alignmentClusterIdx + " has " + size + " peaks");
				double intenses[] = new double[peaksets.size()];
				for (IPeak p : alignmentCluster) {

					if (size == 2) {
						peaksInTwoClusters++;
					} else if (size == 3) {
						peaksInThreeClusters++;
					}
					
					int sourcePeakset = p.getAnnotation(Annotation.sourcePeakset).getValueAsInteger();
					AlignmentEntry matData = new AlignmentEntry(
							alignmentClusterIdx,												// cluster id
							0,																	// bin id
							sourcePeakset,														// peakset id (the input file)
							p.getAnnotation(Annotation.peakId).getValueAsInteger(),				// peak id
							p.getAnnotation(Annotation.relationid).getValueAsInteger(),			// related peaks group id										
							p.getMass(),			// peak mass
							p.getRetentionTime(),	// peak retention time
							p.getIntensity()		// peak intensity
					);
					System.out.println(matData);
					if (size == 2) {
						intenses[sourcePeakset] = p.getIntensity();							
					}
					
				}
				alignmentClusterIdx++;		
				if (size == 2) {
					intensesAll.add(intenses);
				}
				
			}
												
		}
		
		evaluateResult(peaksets.size(), totalPeaks, peaksInThreeClusters,
				peaksInTwoClusters, intensesAll);
		
	}

	public List<IPeakSet<IPeak>> matchPeaksInClusters(final Options options,
			Vector<IPeakSet<IPeak>> peaksets, AlignmentResult align) {
		List<RelatedPeaksCluster> relatedPeaksClusters = align.getRelatedPeaksClusters();
		
		// combine clustered peaks by their original file
		Map<Integer, List<IPeak>> combined = new TreeMap<Integer, List<IPeak>>();
		for (RelatedPeaksCluster rpc : relatedPeaksClusters) {
			int sourcePeakSet = rpc.getSourcePeakSet();
			List<IPeak> temp = new ArrayList<IPeak>(unpack(rpc.getPeaks()));
			if (combined.get(sourcePeakSet) != null) {
				combined.get(sourcePeakSet).addAll(temp);
			} else {
				combined.put(sourcePeakSet, temp);
			}
		}					

		// debugging only
		Vector<IPeakSet<IPeak>> alignedPeaksets = new Vector<IPeakSet<IPeak>>();
		for (int i = 0; i < peaksets.size(); i++) {
			List<IPeak> temp = combined.get(i);
			if (temp != null) {
				IPeakSet<IPeak> ps = new IPeakSet<IPeak>(temp);
				alignedPeaksets.add(ps);
			}
		}					
							
		// greedily match peaks across files
		List<IPeakSet<IPeak>> matches = IPeak.match(alignedPeaksets, options.ppm, new PeakMatchCompare<IPeak>(options.rtwindow));
		return matches;
		
	}

	public List<AlignmentResult> binAndAlign(final Options options,
			Header header, Vector<IPeakSet<IPeak>> peaksets,
			final Random random, CorrelationMeasure measure, float rangeMin,
			float rangeMax) throws IOException {
		
		// create a consistent set of bins across all the input files
		System.out.println("Creating bins ...");
		BinConstructor constructor = new BinConstructor();
		final List<BinInterval> allMyBins = constructor.constructBins(peaksets, options.ppm);
		System.out.println(allMyBins.size() + " bins created");

		// TODO: should create a new object for storing all these ?!
		
		// map between bin id (of all bins across all files) and their member peaks
		Map<Integer, BinInterval> binToPeaksMap = new HashMap<Integer, BinInterval>();
						
		for (int i = 0; i < peaksets.size(); i++) {
			
			IPeakSet<IPeak> peaks = peaksets.get(i);
			preprocess(peaks);
								
			/*
			 * Convert bins from list into a priority queue. We can use this later 
			 * to poll and peek at the head of the queue (the first bin, according 
			 * to its start-end m/z values) easily. 
			 * 
			 * Useful when finding which (sorted) peaks fall into which bins.
			 */
			BinConstructor.BinIntervalComparator comparator = new BinConstructor.BinIntervalComparator();
			PriorityQueue<BinInterval> consistentBins = new PriorityQueue<BinInterval>(10, comparator);
			for (BinInterval myBin : allMyBins) {
				consistentBins.add(new BinInterval(myBin));						
			}
			
			// Finally do the actual binning
			String input = options.input.get(i);
			System.out.println("Binning " + input);
			Map<Integer, BinInterval> peakBins = constructor.binPeaks(consistentBins, peaks, i);

			// merge the output from binning this file to the main bin map
			updateMasterList(binToPeaksMap, peakBins);
			
		}
		
		/* 
		 * Go through resulting bins in the main bin map. Here we want to reinitialize the bin
		 * ids to start sequentially from 0 to binToPeaksMap.size() without any gap. 
		 * Then we will annotate this newly-reset bin IDs to the corresponding peaks in the bin.
		 */
		binToPeaksMap = updateBinIndices(peaksets, binToPeaksMap);		
		final int noOfBins = binToPeaksMap.size();
		System.out.println("No. of non-empty bins: " + noOfBins);
	
		// returns a list of the maps between cluster ids to their corresponding bin forms
		List<Map<Integer, List<Integer>>> clusterToBinsMap = clusterBins(
				options, header, peaksets, random, measure, rangeMin,
				rangeMax);
		
		Map<Integer, RelatedPeaksCluster> clusterToPeaksMap = selectPeaks(
				noOfBins, clusterToBinsMap, binToPeaksMap, options.input);
		
		ModelBasedAlignment aligner = new ModelBasedAlignment(clusterToPeaksMap);
		List<AlignmentResult> alignmentClusters = aligner.align(CombineTask.NO_OF_ALIGNMENT_CLUSTERS);
		return alignmentClusters;
		
	}
	
	private void updateMasterList(
			Map<Integer, BinInterval> binToPeaksMap,
			Map<Integer, BinInterval> peakBins) {
		for (Entry<Integer, BinInterval> e : peakBins.entrySet()) {
			int key = e.getKey();
			BinInterval check = binToPeaksMap.get(key);
			if (check == null) {
				binToPeaksMap.put(e.getKey(), e.getValue());
			} else {
				check.mergePeaks(e.getValue());
			}
		}
	}
	
	private Map<Integer, BinInterval> updateBinIndices(
			Vector<IPeakSet<IPeak>> peaksets,
			Map<Integer, BinInterval> binToPeaksMap) {
	
		System.out.println("Annotating peaks with bin ids");

		int newId = 0;
		
		// mapping between the new IDs and the existing bins
		Map<Integer, BinInterval> result = new HashMap<Integer, BinInterval>();

		// used to iterate through bins in sorted order
		List<BinInterval> sortedBins = new ArrayList<BinInterval>(binToPeaksMap.values());
		Collections.sort(sortedBins, new BinConstructor.BinIntervalComparator());
		
		for (BinInterval bin : sortedBins) {

			// reset bin id
			bin.setIndex(newId);
			result.put(newId, bin);
			
			// for every peak in this bin, we want to annotate them with this bin's id
			List<BinData> binData = bin.getData();
			for (BinData data : binData) {
				annotatePeak(peaksets, bin, data);
			}

			newId++;
			
		}
		
		return result;

	}
	
	/**
	 * Clusters peaks and get their corresponding clusters in bin form
	 * @param options
	 * @param header
	 * @param peaksets
	 * @param random
	 * @param measure
	 * @param rangeMin
	 * @param rangeMax
	 * @return A map from cluster ids to the lists of bin IDs. 
	 * 		Each entry in the map corresponds to a cluster and its bin form.
	 */
	private List<Map<Integer, List<Integer>>> clusterBins(
			final Options options, Header header,
			Vector<IPeakSet<IPeak>> peaksets, final Random random,
			CorrelationMeasure measure, float rangeMin, float rangeMax) {
		
		List<Map<Integer, List<Integer>>> clusterToBinsMap = new ArrayList<Map<Integer, List<Integer>>>();
		for (int i = 0; i < peaksets.size(); i++) {
			
			IPeakSet<IPeak> peaks = peaksets.get(i);
			
			/* 
			 * cluster the basepeaks here by their correlations
			 * each peak will have the annotation "relationid" for the cluster it belongs to
			 */
			// System.out.println("Clustering related peaks from sourcePeakSet " + i);
			// List<IPeak> basepeaks = correlationClustering(options,
			//		header, random, measure, rangeMin, rangeMax, peaks);
			// System.out.println("Found " + basepeaks.size() + " related peaks clusters");

			// get the bin id of each peak in a cluster
			Map<Integer, List<Integer>> binMap = new HashMap<Integer, List<Integer>>();
			for (int j = 0; j < peaks.size(); j++) {

				IPeak peak = peaks.get(j);
				
				// the bin id annotation was set during our binning step
				Annotation ids = peak.getAnnotation(Annotation.binId);
				if (ids == null) {
					System.out.println("Shouldn't happen !!");
				}

				// should never happen if binning was done correctly !!
				assert (ids != null);

				String[] idTokens = ids.getValueAsString().split(",");
				for (int k = 0; k < idTokens.length; k++) {
					String tok = idTokens[k];
					int binId = Integer.parseInt(tok.trim());
					mapClusterToBinIds(binMap, peak, binId);
				}
										
			}		
			
			clusterToBinsMap.add(binMap);
			
		}
		
		// sort clusters by 
		return clusterToBinsMap;
		
	}	
	
	private Map<Integer, RelatedPeaksCluster> selectPeaks(final int noOfBins,
			List<Map<Integer, List<Integer>>> clusterToBinsMap, 
			Map<Integer, BinInterval> binToPeaksMap,
			List<String> fileNames) throws IOException {
		
		final int m = noOfBins;
		int tot = getTotalNoOfClusters(clusterToBinsMap);
		int n = CombineTask.TOP_N_CLUSTERS_FOR_ALIGNMENT * clusterToBinsMap.size();
		if (n > tot) {
			n = tot;
		}
		System.out.println("n x m = " + n + " x " + m);
		final FlexCompRowMatrix documentToBinMatrix = new FlexCompRowMatrix(n, m);

		// for all the input files
		int fileIdx = 0;		
		int allClusterIdx = 0;
		
		Map<Integer, RelatedPeaksCluster> clusterToPeaksMap = new HashMap<Integer, RelatedPeaksCluster>();
		List<AlignmentEntry> allData = new ArrayList<AlignmentEntry>();
		List<IPeakSet<IPeak>> allPeaksets = new ArrayList<IPeakSet<IPeak>>();
		for (Map<Integer, List<Integer>> eachFile : clusterToBinsMap) {

			// System.out.println();
			// System.out.println("****************************************************************************************************************");
			// System.out.println("\tFILE " + fileNames.get(fileIdx));
			// System.out.println("****************************************************************************************************************");
			// System.out.println();

			List<IPeakSet<IPeak>> filePeaks = new ArrayList<IPeakSet<IPeak>>();
			
			// sort by bin size descending order, useful for visualisation (spy) in matlab
			List<List<Integer>> sortedClusterIndices = new ArrayList<List<Integer>>(eachFile.values());
			Collections.sort(sortedClusterIndices, new ListSizeComparator<Integer>());

			int currentClusterCounter = 0;
			for (List<Integer> clusterToBinIndices : sortedClusterIndices) {
			
				if (currentClusterCounter >= CombineTask.TOP_N_CLUSTERS_FOR_ALIGNMENT) {
					System.out.println("Top-N clusters reached");
					break;
				}
								
				// System.out.println("Cluster #" + allClusterIdx + ": " + clusterToBinIndices.size() + " bins");
				IPeakSet<IPeak> peaks = processBin(binToPeaksMap, documentToBinMatrix, fileIdx,
						allClusterIdx, allData, clusterToBinIndices);	
				
				/* 
				 * The cluster id here is not the same as what we got in clusterToBinsMap.
				 * Here, we're renumbering all the clusters sequentially ACROSS all the input files to combine
				 */
				RelatedPeaksCluster rpc = new RelatedPeaksCluster(allClusterIdx, fileIdx, peaks);
				clusterToPeaksMap.put(rpc.getClusterId(), rpc);
				
				// System.out.println("peaks: " + peaks.size());
				filePeaks.add(peaks);
				currentClusterCounter++;
				allClusterIdx++;

			}
			// System.out.println();
			fileIdx++;

			IPeakSet<IPeak> packed = new IPeakSet(filePeaks);
			IPeakSet<IPeak> related = new IPeakSet<IPeak>(unpack(packed));
			allPeaksets.add(related);
			
		}
		
		/*
		 * write out to matlab
		 */
		
		final String path = CombineTask.MATLAB_OUTPUT_PATH;
		final String filename = CombineTask.MATLAB_OUTPUT_FILENAME;
		final String fullPath = path + "/" + filename;
		
		final Collection<MLArray> outputMat = new ArrayList<MLArray>();

		// prepare the input matrix X
		System.out.println("Writing X: ");
		matlabMatrix(documentToBinMatrix, outputMat);
		
		// prepare the additional peak info matrix
		matlabPeakInfo(allData, outputMat);
		
		// actually write to the file here 
		final MatFileWriter writer = new MatFileWriter();
		System.out.println("Written to " + fullPath);
		writer.write(fullPath, outputMat);
				
		return clusterToPeaksMap;
		
	}	
	
	private void annotatePeak(Vector<IPeakSet<IPeak>> peaksets,
			BinInterval bin, BinData data) {
		
		IPeak peakInBin = data.getPeak();
		int sourcePeakSet = data.getSourcePeakSet();
		
		// the pattern id stores the original position of the peak in the peakset
		int peakPosition = peakInBin.getPatternID();
		
		// retrieve the peak among the peaksets
		IPeakSet<IPeak> peaks = peaksets.get(sourcePeakSet);
		IPeak peak = peaks.get(peakPosition);
		
		// now annotate the bin id to the peak
		int binId = bin.getIndex();
		final Annotation annotation = peak.getAnnotation(Annotation.binId);
		if (annotation != null) {
			peak.addAnnotation(Annotation.binId, annotation.getValue() + "," + binId);					
		} else {
			peak.addAnnotation(Annotation.binId, binId);					
		}

	}	

	private void mapClusterToBinIds(Map<Integer, List<Integer>> binMap,
			IPeak peak, int binId) {
		
		// here, cluster id is actually the same as the base peak id
		int clusterId = peak.getAnnotation(IPeak.relationid).getValueAsInteger();
		
		// store a map between a cluster id and its corresponding bin form
		if (binMap.containsKey(clusterId)) {
			binMap.get(clusterId).add(binId);
		} else {
			List<Integer> clusterBins = new ArrayList<Integer>();
			clusterBins.add(binId);
			binMap.put(clusterId, clusterBins);
		}

	}
	
	private int getTotalNoOfClusters(
			List<Map<Integer, List<Integer>>> clusterToBinsList) {
		int n = 0;
		for (Map<Integer, List<Integer>> binMap : clusterToBinsList) {
			n += binMap.keySet().size();
		}
		return n;
	}
	
	private IPeakSet<IPeak> processBin(Map<Integer, BinInterval> binToPeaksMap,
			final FlexCompRowMatrix documentToBinMatrix, int fileIdx,
			int allClusterIdx, List<AlignmentEntry> allData,
			List<Integer> clusterToBinIndices) {
		
		Set<IPeak> unique = new HashSet<IPeak>();
		
		// print out the biggest clusters				
		Collections.sort(clusterToBinIndices);
		for (int binIndex : clusterToBinIndices) {
			BinInterval bin = binToPeaksMap.get(binIndex);
			if (bin == null) {
				System.out.println("Shouldn't happen");
				continue;
			}
			List<BinData> allBinData = bin.getData();
			// System.out.println("\tbinID " + bin.getIndex() + 
			//		" (" + String.format("%4.8f", bin.getBinStart()) + 
			//		"-" + String.format("%4.8f", bin.getBinEnd()) + ")");
			for (BinData d : allBinData) {
				if (d.getSourcePeakSet() == fileIdx) {
					IPeak p = d.getPeak();
					unique.add(p);
					AlignmentEntry matData = new AlignmentEntry(
							allClusterIdx,		// cluster id
							bin.getIndex(),		// bin id
							d.getSourcePeakSet(),	// peakset id (the input file)
							p.getPatternID(),		// peak id
							p.getAnnotation(Annotation.relationid).getValueAsInteger(),
							p.getMass(),			// peak mass
							p.getRetentionTime(),	// peak retention time
							p.getIntensity()		// peak intensity
					);
					allData.add(matData);
					// System.out.println(matData);
					documentToBinMatrix.add(allClusterIdx, binIndex, 1);							
				}
			}
		}
		
		IPeakSet<IPeak> peakset = new IPeakSet<IPeak>(new ArrayList<IPeak>(unique));
		return peakset;
		
	}	
	
	private void matlabMatrix(
			final FlexCompRowMatrix documentToBinMatrix,
			final Collection<MLArray> outputMat) {
		final int nRows = documentToBinMatrix.numRows();
		final int nCols = documentToBinMatrix.numColumns();
		int[] dims = {nRows, nCols};
		final int nnz = ShapeCorrelations.nonZeros(documentToBinMatrix);
		System.out.println("\tnnz: " + nnz);
		System.out.println("\tdims: " + dims[0 ] + "x" + dims[1]);
		final MLSparse matrix = new MLSparse("X", dims, 0, nnz);
		outputMat.add(matrix);
		for (MatrixEntry e : documentToBinMatrix) {
			final int rowIdx = e.row();
			final int colIdx = e.column();
			final double value = e.get();
			matrix.set(value, rowIdx, colIdx);
		}
	}

	private void matlabPeakInfo(List<AlignmentEntry> allData,
			final Collection<MLArray> outputMat) {
		double[][] peakInfo = new double[allData.size()][7];
		for (int i = 0; i < allData.size(); i++) {
			AlignmentEntry data = allData.get(i);
			peakInfo[i][0] = data.getClusterId();
			peakInfo[i][1] = data.getBinId();
			peakInfo[i][2] = data.getSourcePeakSet();
			peakInfo[i][3] = data.getPeakId();
			peakInfo[i][4] = data.getMass();
			peakInfo[i][5] = data.getRt();
			peakInfo[i][6] = data.getIntensity();
		}
		MLDouble mlDouble = new MLDouble("peak_info", peakInfo);
		outputMat.add(mlDouble);
	}
	
}
