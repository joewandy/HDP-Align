package mzmatch.ipeak;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Vector;

import mzmatch.ipeak.Combine.Options;
import mzmatch.ipeak.sort.CorrelationMeasure;

import org.apache.commons.collections15.Bag;

import peakml.Annotation;
import peakml.IPeak;
import peakml.IPeakSet;
import peakml.io.Header;
import peakml.io.ParseResult;
import cern.colt.Arrays;

import com.joewandy.mzmatch.model.AlignmentEdge;
import com.joewandy.mzmatch.model.AlignmentEntry;
import com.joewandy.mzmatch.model.AlignmentExpParam;
import com.joewandy.mzmatch.model.AlignmentExpResult;
import com.joewandy.mzmatch.model.AlignmentPair;
import com.joewandy.mzmatch.model.AlignmentResult;
import com.joewandy.mzmatch.model.AlignmentVertex;
import com.rits.cloning.Cloner;

public class CombineGraphTask extends CombineFilterTask implements CombineTask {
	
	private static final String GRAPH_EXPORT_EXTENSION = ".net";
	private static final String GRAPH_EXPORT_PATH = "/home/joewandy/Dropbox/workspace/mzmatch/datasets/alignment_";

	public void process(Options options, Header header,
			Vector<IPeakSet<IPeak>> peaksets, ParseResult[] results,
			final Random random, CorrelationMeasure measure, float rangeMin,
			float rangeMax, int totalPeaks, OutputStream output) throws IOException, FileNotFoundException {
		
		System.out.println();
		System.out.println("*************************************");
		System.out.println("GROUPING PEAKS");
		System.out.println("*************************************");		
		
		/*
		 * Find related peaks, using the grouping methods specified.
		 * Note: grouping parameters are hard-coded into the methods directly, should remember to take them out ..
		 */
		final String groupingMethod = CombineTask.GREEDY_GROUPING;
		List<Map<Integer, List<IPeak>>> clusterToPeaksMap = groupPeaks(
				options, header, peaksets, random, 
				measure, rangeMin, rangeMax, groupingMethod);	
		
		final String alignmentMethod = CombineTask.EXPERIMENT_ALIGNMENT;
		if (CombineTask.GREEDY_ALIGNMENT.equals(alignmentMethod)) {

			System.out.println();
			System.out.println("*************************************");
			System.out.println("RANDOMISING ENTRIES");
			System.out.println("*************************************");		
			
			clusterToPeaksMap = randomiseEntries(clusterToPeaksMap);
			
			System.out.println();
			System.out.println("*************************************");
			System.out.println("REMOVING UNWANTED PEAKS");
			System.out.println("*************************************");		
			
			// filter peaks by discarding anything but the top-N groups, if necessary
			List<IPeakSet<IPeak>> groupedPeaksets = filterPeaksByGroups(clusterToPeaksMap, options.input, Integer.MAX_VALUE);				

			System.out.println();
			System.out.println("*************************************");
			System.out.println("ALIGNING PEAKS");
			System.out.println("*************************************");	
			
			AlignmentExpParam param = new AlignmentExpParam("greedy_alignment", 0, 0, false, 1, false, false, peaksets.size());
			System.out.println(param);
			
			// the resulting combined peaksets to write to output
			List<IPeakSet<IPeak>> data = new ArrayList<IPeakSet<IPeak>>();

			List<AlignmentEdge> edgeList = new ArrayList<AlignmentEdge>();
			alignMzMatch(options, peaksets, totalPeaks, clusterToPeaksMap,
					groupedPeaksets, data, edgeList);
			analyseGraph(edgeList, param);
			
			// writePeaks(options, results, data);
			
		} else if (CombineTask.MODEL_BASED_ALIGNMENT.equals(alignmentMethod)){

			System.out.println();
			System.out.println("*************************************");
			System.out.println("RANDOMISING ENTRIES");
			System.out.println("*************************************");		
			
			clusterToPeaksMap = randomiseEntries(clusterToPeaksMap);
			
			System.out.println();
			System.out.println("*************************************");
			System.out.println("REMOVING UNWANTED PEAKS");
			System.out.println("*************************************");		
			
			// filter peaks by discarding anything but the top-N groups, if necessary
			List<IPeakSet<IPeak>> groupedPeaksets = filterPeaksByGroups(clusterToPeaksMap, options.input, Integer.MAX_VALUE);				

			System.out.println();
			System.out.println("*************************************");
			System.out.println("ALIGNING PEAKS");
			System.out.println("*************************************");	
			
			AlignmentExpParam param = new AlignmentExpParam("model_based_alignment", 3, 30, false, 1, false, false, peaksets.size());
			System.out.println(param);

			// the resulting combined peaksets to write to output
			List<IPeakSet<IPeak>> data = new ArrayList<IPeakSet<IPeak>>();
			
			List<AlignmentEdge> edgeList = new ArrayList<AlignmentEdge>();
			alignMixture(options, header, peaksets, random, measure, rangeMin,
					rangeMax, totalPeaks, clusterToPeaksMap, data, edgeList);	
			analyseGraph(edgeList, param);

			// writePeaks(options, results, data);
			
		} else if (CombineTask.EXPERIMENT_ALIGNMENT.equals(alignmentMethod)) {
			
			List<AlignmentExpParam> parameters = new ArrayList<AlignmentExpParam>();

			/* 
			 * NOte. multigraph parameter is not used
			 */
			
			// parameters.add(new AlignmentExpParam("strict_alignment_random", 1, 10, true, 1, false, true, peaksets.size()));
			parameters.add(new AlignmentExpParam("strict_alignment_nonrandom", 1, 10, false, 1, false, true, peaksets.size()));

			// parameters.add(new AlignmentExpParam("normal_alignment_random", 3, 30, true, 500, false, false, peaksets.size()));
			// parameters.add(new AlignmentExpParam("normal_alignment_nonrandom", 3, 30, false, 1, false, true, peaksets.size()));
			
			// parameters.add(new AlignmentExpParam("relaxed_alignment_random", 6, 30, true, 500, false, false, peaksets.size()));
			parameters.add(new AlignmentExpParam("relaxed_alignment_nonrandom", 10, 300, false, 1, false, true, peaksets.size()));

			Cloner cloner = new Cloner();
			
			List<Map<Integer, List<IPeak>>> myClonedMap = new ArrayList<Map<Integer, List<IPeak>>>();
			for (AlignmentExpParam parameter : parameters) {

				parameter.copyToOption(options);
				System.out.println(parameter);
				
				// the resulting combined peaksets to write to output
				List<IPeakSet<IPeak>> data = new ArrayList<IPeakSet<IPeak>>();
				
				// collect all the alignment results here for performance evaluation
				AlignmentExpResult experimentResult = new AlignmentExpResult();
				
				// repeat the experiment many times
				for (int i = 0; i < parameter.getIteration(); i++) {

					if (i % 100 == 0) {
						System.out.println("\nIteration #" + i);
					} else if (i % 10 == 0) {
						System.out.print(".");
					}					
					
					/*
					 * MUST remember to clone clusterToPeaksMap between each iteration
					 * 
					 * IPeak objects don't implement clonable, don't want to fuss around with
					 * adding a copy constructor to them too. One way is to serialize/deserialize them.
					 * 
					 * Quick workaround: http://stackoverflow.com/questions/665860/deep-clone-utility-recomendation
					 */
					
					// avoid gc error
					myClonedMap.clear();
					myClonedMap = cloner.deepClone(clusterToPeaksMap);
					
					// randomly permute peak grouping labels
					if (parameter.isRandomise()) {
						myClonedMap = randomiseEntries(myClonedMap);						
					}
					
					// filter peaks by discarding anything but the top-N groups, if necessary
					List<IPeakSet<IPeak>> groupedPeaksets = filterPeaksByGroups(myClonedMap, options.input, Integer.MAX_VALUE);				

					// aligning peaks
					List<AlignmentEdge> edgeList = new ArrayList<AlignmentEdge>();
					alignMzMatch(options, peaksets, totalPeaks, myClonedMap,
							groupedPeaksets, data, edgeList);
					AlignmentExpResult iterResult = analyseGraph(edgeList, parameter);
					// System.out.println(iterResult);
					experimentResult.collect(iterResult);
										
				}

				System.out.println();
				System.out.println("*************************************");
				System.out.println("FINAL RESULT");
				System.out.println(parameter);
				System.out.println("*************************************");	
				
				System.out.println(experimentResult);

				// generate matlab-friendly output
				printForMatlab(parameter, experimentResult);
				
				// writePeaks(options, results, data);
				
			}
			
		} else if (CombineTask.INTERACTIVE_ALIGNMENT.equals(alignmentMethod)) {
			
			AlignmentExpParam parameter = new AlignmentExpParam("default_alignment", 3, 30, false, 1, false, true, peaksets.size());
			parameter.copyToOption(options);
			System.out.println(parameter);

			Cloner cloner = new Cloner();
			List<Map<Integer, List<IPeak>>> myClonedMap = cloner.deepClone(clusterToPeaksMap);
			
			// the resulting combined peaksets to write to output
			List<IPeakSet<IPeak>> data = new ArrayList<IPeakSet<IPeak>>();
										
			// filter peaks by discarding anything but the top-N groups, if necessary
			List<IPeakSet<IPeak>> groupedPeaksets = filterPeaksByGroups(myClonedMap, options.input, Integer.MAX_VALUE);				

			// aligning peaks
			List<AlignmentEdge> edgeList = new ArrayList<AlignmentEdge>();
			alignMzMatch(options, peaksets, totalPeaks, myClonedMap,
					groupedPeaksets, data, edgeList);
			AlignmentExpResult experimentResult = analyseGraph(edgeList, parameter);

			System.out.println();
			System.out.println("*************************************");
			System.out.println("FINAL RESULT");
			System.out.println(parameter);
			System.out.println("*************************************");	
			
			System.out.println(experimentResult);

			// generate matlab-friendly output
			printForMatlab(parameter, experimentResult);
			
			// writePeaks(options, results, data);
			
		}
						
	}

	private void printForMatlab(AlignmentExpParam parameter,
			AlignmentExpResult experimentResult) {
	
		Bag<Integer> degreeDistribution = experimentResult.getDegreeDistribution();
		List<Integer> uniqueDegrees = new ArrayList<Integer>(degreeDistribution.uniqueSet());

//		int maxDegree = Collections.max(uniqueDegrees);
//		int[] vertexDegrees = new int[maxDegree];
//		int[] vertexDegreesCounts = new int[maxDegree];
//		for (int i = 0; i < maxDegree; i++) {
//			vertexDegrees[i] = i;
//			vertexDegreesCounts[i] = degreeDistribution.getCount(vertexDegrees[i]);
//		}

		int[] vertexDegrees = new int[uniqueDegrees.size()];
		int[] vertexDegreesCounts = new int[uniqueDegrees.size()];
		for (int i = 0; i < uniqueDegrees.size(); i++) {
			int degree = uniqueDegrees.get(i);
			vertexDegrees[i] = degree;
			vertexDegreesCounts[i] = degreeDistribution.getCount(vertexDegrees[i]);
		}
		
		System.out.println("vertex_degrees_" + parameter.getLabel() + " = " + Arrays.toString(vertexDegrees) + ";");
		System.out.println("vertex_degrees_counts_" + parameter.getLabel() + " = " + Arrays.toString(vertexDegreesCounts) + ";");				

		Bag<Double> edgeDistribution = experimentResult.getEdgeWeightDistribution();
		Map<Double, Double> intensityByEdgeWeight = experimentResult.getIntensityByEdgeWeight();
		Map<Double, Integer> groupSizeByEdgeWeight = experimentResult.getGroupSizeByEdgeWeight();
		List<Double> uniqueEdges = new ArrayList<Double>(edgeDistribution.uniqueSet());

//		double temp = Collections.max(uniqueEdges);
//		int maxEdge = (int) temp;
//		double[] edgeWeights = new double[maxEdge];
//		int[] edgeWeightsCounts = new int[maxEdge];
//		double[] intensities = new double[maxEdge];
//		for (int i = 0; i < maxEdge; i++) {
//			edgeWeights[i] = i;
//			edgeWeightsCounts[i] = edgeDistribution.getCount(edgeWeights[i]);
//			double intense = 0;
//			if (intensityByEdgeWeight.containsKey(edgeWeights[i])) {
//				double sumIntensity = intensityByEdgeWeight.get(edgeWeights[i]);
//				intense = sumIntensity / edgeWeightsCounts[i];
//			}
//			intensities[i] = intense;
//		}

		double[] edgeWeights = new double[uniqueEdges.size()];
		int[] edgeWeightsCounts = new int[uniqueEdges.size()];
		double[] intensities = new double[uniqueEdges.size()];
		int[] groupSizes = new int[uniqueEdges.size()];
		for (int i = 0; i < uniqueEdges.size(); i++) {
			edgeWeights[i] = uniqueEdges.get(i);
			edgeWeightsCounts[i] = edgeDistribution.getCount(edgeWeights[i]);
			double sumIntensity = intensityByEdgeWeight.get(edgeWeights[i]);
			double intense = sumIntensity / edgeWeightsCounts[i];
			intensities[i] = intense;
			groupSizes[i] = groupSizeByEdgeWeight.get(edgeWeights[i]);
		}
		
		List<AlignmentPair> allAlignments = experimentResult.getAlignmentPairs();
		double[] alignmentPairErr = new double[allAlignments.size()];
		double[] alignmentPairScore = new double[allAlignments.size()];
		int i = 0;
		for (AlignmentPair align : allAlignments) {
			alignmentPairErr[i] = align.getRelativeIntensityErrorScore();
			alignmentPairScore[i] = align.getScore();
			i++;
		}
		
		System.out.println("edge_weights_" + parameter.getLabel() + " = " + Arrays.toString(edgeWeights) + ";");
		System.out.println("edge_weights_counts_" + parameter.getLabel() + " = " + Arrays.toString(edgeWeightsCounts) + ";");				
		System.out.println("intensities_" + parameter.getLabel() + " = " + Arrays.toString(intensities) + ";");				
		System.out.println("group_size_" + parameter.getLabel() + " = " + Arrays.toString(groupSizes) + ";");				
		System.out.println("alignment_intensity_" + parameter.getLabel() + " = " + Arrays.toString(alignmentPairErr) + ";");				
		System.out.println("alignment_score_" + parameter.getLabel() + " = " + Arrays.toString(alignmentPairScore) + ";");				

		System.out.println();

	}

	private List<Map<Integer, List<IPeak>>> randomiseEntries(
			List<Map<Integer, List<IPeak>>> clusterToPeaksMap) {
		
		List<Map<Integer, List<IPeak>>> randomisedClusterToPeaksMap = new ArrayList<Map<Integer, List<IPeak>>>();
		for (int i = 0; i < clusterToPeaksMap.size(); i++) {

			Map<Integer, List<IPeak>> eachFile = clusterToPeaksMap.get(i);
			
			// collect all peaks
			List<IPeak> allPeaks = new ArrayList<IPeak>();
			for (List<IPeak> peaks : eachFile.values()) {
				allPeaks.addAll(peaks);
			}
			
			// randomise them
			randomiseGroupIds(allPeaks);
			
			// reconstruct a new map
			Map<Integer, List<IPeak>> randomisedMapping = mapPeaksToGroups(new IPeakSet<IPeak>(allPeaks));
			
			randomisedClusterToPeaksMap.add(randomisedMapping);
			
		}
		
		return randomisedClusterToPeaksMap;
		
	}
	
	private AlignmentExpResult analyseGraph(List<AlignmentEdge> edgeList, AlignmentExpParam parameter) throws IOException {

		CombineGraphView combineGraphView = new CombineGraphView(edgeList, false, parameter.getDataFileCount(), 0);
		AlignmentExpResult result = combineGraphView.computeStatistics();

		if (parameter.isVisualise()) {
			final String myLayout = CombineGraphView.LAYOUT_SPRING;
			final String msg = parameter.toString();
			combineGraphView.visualiseGraph(parameter.getLabel(), msg, 1000, 700, combineGraphView.getAlignmentGraph(), myLayout);
		}

		// graphView.findCluster("Subgraph", myLayout);
		// graphView.exportGraph(CombineGraphTask.GRAPH_EXPORT_PATH + parameter.getLabel() + CombineGraphTask.GRAPH_EXPORT_EXTENSION);

		return result;
		
	}

	private void alignMixture(final Options options, Header header,
			Vector<IPeakSet<IPeak>> peaksets, final Random random,
			CorrelationMeasure measure, float rangeMin, float rangeMax,
			int totalPeaks, List<Map<Integer, List<IPeak>>> clusterToPeaksMap,
			List<IPeakSet<IPeak>> data, List<AlignmentEdge> edgeList)
			throws IOException {
		// mixture model matching
		CombineSampleTask sampleTask = new CombineSampleTask();
		List<AlignmentResult> alignmentClusters = sampleTask.binAndAlign(options, header,
				peaksets, random, measure, rangeMin, rangeMax);
		
//		System.out.println();
//		System.out.println("===========================================");
//		System.out.println("MODEL-BASED ALIGNMENT");
//		System.out.println("===========================================");
//		System.out.println();
		
		for (AlignmentResult align : alignmentClusters) {
			List<IPeakSet<IPeak>> matches = sampleTask.matchPeaksInClusters(options,
					peaksets, align);						
			processAlignment(peaksets, totalPeaks, clusterToPeaksMap, matches, data, edgeList);
		}
	
	}

	private void alignMzMatch(final Options options,
			Vector<IPeakSet<IPeak>> peaksets, int totalPeaks,
			List<Map<Integer, List<IPeak>>> clusterToPeaksMap,
			List<IPeakSet<IPeak>> groupedPeaksets, List<IPeakSet<IPeak>> data,
			List<AlignmentEdge> edgeList) {
		
//		System.out.println();
//		System.out.println("===========================================");
//		System.out.println("MZMATCH ORIGINAL ALIGNMENT");
//		System.out.println("===========================================");
//		System.out.println();
		
		List<IPeakSet<IPeak>> matches = IPeak.match(groupedPeaksets, options.ppm, new PeakMatchCompare<IPeak>(options.rtwindow));						

		// process alignment result & print a whole bunch of statistics
		processAlignment(peaksets, totalPeaks, clusterToPeaksMap, matches, data, edgeList);

	}

	private void processAlignment(Vector<IPeakSet<IPeak>> peaksets,
			int totalPeaks, List<Map<Integer, List<IPeak>>> clusterToPeaksMap,
			List<IPeakSet<IPeak>> matches, List<IPeakSet<IPeak>> data, List<AlignmentEdge> edgeList) {
		
		int peaksInThreeClusters = 0;
		int peaksInTwoClusters = 0;
		List<double[]> intensesAll = new ArrayList<double[]>();

		// System.out.println("Total matches = " + matches.size());
		int singleton = 0;
		int pairwise = 0;
		int triplet = 0;
		for (IPeakSet<IPeak> match : matches) {
			if (match.size() == 1) {
				singleton++;
			} else if (match.size() == 2) {
				pairwise++;
			} else if (match.size() == 3) {
				triplet++;
			}
		}
//		System.out.println("Singleton = " + singleton);
//		System.out.println("Pairwise = " + pairwise);
//		System.out.println("Triplet = " + triplet);
		
		int limit = Math.min(matches.size(), CombineTask.TOP_N_CLUSTERS_FOR_GRAPH);
		int success = 0;
		Map<String, AlignmentVertex> allVertices = new HashMap<String, AlignmentVertex>();
		for (int matchId = 0; matchId < matches.size(); matchId++) {
								
			IPeakSet<IPeak> match = matches.get(matchId);
			
			// unpack potential sub-peaksets
			IPeakSet<IPeak> alignmentCluster = new IPeakSet<IPeak>(unpack(match));
			int size = alignmentCluster.size();
			if (size == 1) {
				// ignore peaks that we don't want
				continue;
			}
			
			double intenses[] = new double[peaksets.size()];
//			System.out.println("\nAlignment Cluster #" + matchId + " has " + size + " peaks");

			List<AlignmentVertex> vertices = new ArrayList<AlignmentVertex>();
			List<IPeak> alignedPeaks = new ArrayList<IPeak>();
			
//			AlignmentVertex previous = null;
			for (IPeak p : alignmentCluster) {

				if (size == 2) {
					peaksInTwoClusters++;
				} else if (size == 3) {
					peaksInThreeClusters++;
				}

				int sourcePeakset = p.getAnnotation(Annotation.sourcePeakset).getValueAsInteger();
				Annotation relationIdAnnotation = p.getAnnotation(Annotation.relationid);
				int groupId = 0;
				if (relationIdAnnotation != null) {
					groupId = relationIdAnnotation.getValueAsInteger();
				}
				AlignmentEntry currEntry = new AlignmentEntry(
						matchId,															// alignment cluster id
						0,																	// unused
						sourcePeakset,														// peakset id (the input file)
						p.getAnnotation(Annotation.peakId).getValueAsInteger(),				// peak id
						groupId,															// related peaks group id			
						p.getMass(),			// peak mass
						p.getRetentionTime(),	// peak retention time
						p.getIntensity()		// peak intensity
				);
//				System.out.println(currEntry);

				AlignmentVertex current = buildVertex(currEntry, clusterToPeaksMap, allVertices);
				vertices.add(current);	
				alignedPeaks.add(p);
				
//				if (previous != null) {
//					AlignmentEdge edge = new AlignmentEdge(previous, current);
//					edgeList.add(edge);						
//				}
//				previous = current;
				
				// for debugging only
				if (size == 2) {
					intenses[sourcePeakset] = p.getIntensity();							
				}
				
			}		
			
			// link all vertices to each other
			for (int i = 0; i < vertices.size(); i++) {
				for (int j = i; j < vertices.size(); j++) {
					AlignmentVertex v1 = vertices.get(i);
					AlignmentVertex v2 = vertices.get(j);	
					IPeak p1 = alignedPeaks.get(i);
					IPeak p2 = alignedPeaks.get(j);
					if (!v1.equals(v2)) {
						AlignmentPair pair = new AlignmentPair(p1, p2);
						AlignmentEdge edge = new AlignmentEdge(v1, v2, pair);
						edgeList.add(edge);						
					}
				}
			}
			
			data.add(alignmentCluster);
			if (size == 2) {
				intensesAll.add(intenses);
			}
			
			success++;
			if (success > limit) {
				break;
			}
			
		}

		evaluateResult(peaksets.size(), totalPeaks, peaksInThreeClusters,
				peaksInTwoClusters, intensesAll);
				
	}

	private AlignmentVertex buildVertex(AlignmentEntry alignmentEntry,
			List<Map<Integer, List<IPeak>>> clusterToPeaksMap,
			Map<String, AlignmentVertex> allVertices) {

		// construct a new vertex object or retrieve existing ones
		String key = AlignmentVertex.formatId(alignmentEntry.getSourcePeakSet(), alignmentEntry.getGroupId());
		AlignmentVertex vertex = allVertices.get(key);
		if (vertex == null) {
			vertex = new AlignmentVertex(alignmentEntry.getSourcePeakSet(), alignmentEntry.getGroupId());			
			// store peaks in vertices
			Map<Integer, List<IPeak>> singleFileClusterToPeaks = clusterToPeaksMap.get(alignmentEntry.getSourcePeakSet());
			List<IPeak> peaks = singleFileClusterToPeaks.get(alignmentEntry.getGroupId());
			if (peaks != null) {
				vertex.setPeaks(peaks);
			}			
		} else {
			allVertices.put(key, vertex);
		}
				
		return vertex;
					
	}	
		
}
