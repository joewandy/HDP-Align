package mzmatch.ipeak;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.Stroke;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;

import org.apache.commons.collections15.Transformer;

import com.joewandy.mzmatch.model.AlignmentEdge;
import com.joewandy.mzmatch.model.AlignmentVertex;

import edu.uci.ics.jung.algorithms.cluster.WeakComponentClusterer;
import edu.uci.ics.jung.algorithms.filters.FilterUtils;
import edu.uci.ics.jung.algorithms.layout.CircleLayout;
import edu.uci.ics.jung.algorithms.layout.FRLayout;
import edu.uci.ics.jung.algorithms.layout.ISOMLayout;
import edu.uci.ics.jung.algorithms.layout.KKLayout;
import edu.uci.ics.jung.algorithms.layout.Layout;
import edu.uci.ics.jung.algorithms.scoring.DegreeScorer;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedGraph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.BasicVisualizationServer;

public class CombineGraphView2 {

	public static final String LAYOUT_KK = "kk";
	public static final String LAYOUT_FR = "fr";
	public static final String LAYOUT_ISOM = "isom";
	
	private UndirectedGraph<String, String> alignmentGraph;
	private Map<String, Integer> degreeScores;
	
    public CombineGraphView2(List<AlignmentEdge> edgeList) {
		
    	System.out.println("--- CombineGraphViewer initialising ---");
    	Collections.shuffle(edgeList);
    	
    	UndirectedGraph<String, String> alignmentGraph = new UndirectedSparseGraph<String, String>();
    	final int limit = Math.min(edgeList.size(), CombineTask.TOP_N_EDGES_FOR_GRAPH);
		for (int i = 0; i < limit; i++) {
			AlignmentEdge e = edgeList.get(i);
			alignmentGraph.addEdge(e.toString(), e.getLeft().getId(), e.getRight().getId());
			alignmentGraph.addVertex(e.getLeft().getId());
			alignmentGraph.addVertex(e.getRight().getId());
		}

		int vc = alignmentGraph.getVertexCount();
        System.out.println("\tVertices count=" + vc);

        int ec = alignmentGraph.getEdgeCount();
        System.out.println("\tEdges count=" + ec);

        this.alignmentGraph = alignmentGraph;
		this.degreeScores = new HashMap<String, Integer>();

		System.out.println("--- CombineGraphViewer initialised ---");
	
    }
        
    public Graph<String, String> getAlignmentGraph() {
		return alignmentGraph;
	}

	public void printStatistics() {
    	
    	System.out.println("==================================================");
    	System.out.println(" Alignment graph statistics ");
    	System.out.println("==================================================");
    	System.out.println();
    	int totalScore = 0;
        DegreeScorer<String> degreeScorer = new DegreeScorer<String>(alignmentGraph);
        for (String v : alignmentGraph.getVertices()) {
        	int score = degreeScorer.getVertexScore(v);
        	System.out.println("score=" + score);
        	degreeScores.put(v, score);
        	totalScore += score;
        }
        double avgDegree = ((double) totalScore) / alignmentGraph.getVertices().size();
        System.out.println("Average degree=" + avgDegree);
    	
    }
    
    public void visualiseGraph(String title, int width, int height, Graph<String, String> myGraph, String layoutStr) {
 
        // Layout implements the graph drawing logic
    	Layout<String, String> layout = null;
    	if (layoutStr.equals(CombineGraphView.LAYOUT_ISOM)) {
        	layout = new ISOMLayout<String, String>(myGraph);    		
    	} else if (layoutStr.equals(CombineGraphView.LAYOUT_FR)) {
        	layout = new FRLayout<String, String>(myGraph);
    	} else if (layoutStr.equals(CombineGraphView.LAYOUT_KK)) {
        	layout = new KKLayout<String, String>(myGraph);    		
    	} else {
    		// default is circle layout
        	layout = new CircleLayout<String, String>(myGraph);
    	}

    	layout.setSize(new Dimension(width, height));
    	
        // VisualizationServer actually displays the graph
        BasicVisualizationServer<String, String> vv = new BasicVisualizationServer<String, String>(layout);
        vv.setPreferredSize(new Dimension(width, height)); // Sets the viewing area size

        Transformer<String,Shape> vertexSize = new Transformer<String,Shape>(){
            public Shape transform(String v){
                Ellipse2D circle = new Ellipse2D.Double(-2, -2, 4, 4);
            	return AffineTransform.getScaleInstance(1, 1).createTransformedShape(circle);
            }
        };   
        
        vv.getRenderContext().setVertexShapeTransformer(vertexSize);
        		 
        JFrame frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(vv); 
        frame.pack();
        frame.setVisible(true);        	
    	
    }
    
    public void findCluster(String title) {
    	
    	WeakComponentClusterer<String, String> wcc = new WeakComponentClusterer<String, String>();
    	Collection<UndirectedGraph<String, String>> ccs = FilterUtils.createAllInducedSubgraphs(wcc.transform(this.alignmentGraph), this.alignmentGraph);
    	
    	int i = 0;
    	for (Graph<String, String> g : ccs) {
    		int count = g.getVertexCount();
    		System.out.println("Count " + count);
    		if (count > 3) {
        		System.out.println("Count " + count + " graph "+ g);
    			this.visualiseGraph(title + i, 400, 400, g, CombineGraphView.LAYOUT_ISOM);
        		i++;    			
    		} else {
    			continue;
    		}
    	}
    	
    }


	public static void main(String[] args) {
    	
        // Create a graph with Integer vertices and String edges
        Graph<Integer, String> g = new UndirectedSparseGraph<Integer, String>();
        for(int i = 0; i < 7; i++) {
        	g.addVertex(i);
        }
        g.addEdge("E1 (1.0)", 0, 1);
        g.addEdge("E2 (1.0)", 0, 2);
        g.addEdge("E3 (1.0)", 1, 2);
        
        g.addEdge("E4 (1.0)", 0, 3);
        g.addEdge("E5 (1.0)", 0, 4);
        g.addEdge("E6 (1.0)", 3, 4);
        
        g.addEdge("E7 (4.0)", 5, 6);
        g.addEdge("E8 (2.0)", 5, 7);
        g.addEdge("E9 (1.0)", 6, 7);
        
        // Layout implements the graph drawing logic
        Layout<Integer, String> layout = new CircleLayout<Integer, String>(g);
        layout.setSize(new Dimension(300,300));

        // VisualizationServer actually displays the graph
        BasicVisualizationServer<Integer,String> vv = new BasicVisualizationServer<Integer,String>(layout);
        vv.setPreferredSize(new Dimension(350,350)); // Sets the viewing area size

        // Transformer maps the vertex number to a vertex property
        Transformer<Integer,Paint> vertexColor = new Transformer<Integer,Paint>() {
            public Paint transform(Integer i) {
                if(i == 0 || i == 6) {
                	return Color.BLUE;
                } else if (i == 1 || i == 3 || i == 7) {
                	return Color.GREEN;
                } else {
                    return Color.RED;                	
                }
            }
        };
        Transformer<Integer,Shape> vertexSize = new Transformer<Integer,Shape>(){
            public Shape transform(Integer i){
                Ellipse2D circle = new Ellipse2D.Double(-15, -15, 30, 30);
                // in this case, the vertex is twice as large
                if(i == 0) {
                	return AffineTransform.getScaleInstance(2, 2).createTransformedShape(circle);
                } else {
                	return circle;
                }
            }
        };
        Transformer<String, String> edgeLabel = new Transformer<String, String>() {
            public String transform(String e) {
        		return e;
            }
        };        
        
        vv.getRenderContext().setVertexFillPaintTransformer(vertexColor);
        vv.getRenderContext().setVertexShapeTransformer(vertexSize);
        vv.getRenderContext().setEdgeLabelTransformer(edgeLabel);        

        JFrame frame = new JFrame("Simple Graph View");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(vv); 
        frame.pack();
        frame.setVisible(true);        	
    	
    }
    
}