package mzmatch.ipeak;

public class CombineAlignParam {

}
