DIR="$( cd "$( dirname "$0" )" && pwd )"
export JAVA="java -Xmx1024M -ea -cp $DIR/../bin:$DIR/../../cmdline/bin:$DIR/../../domsax/bin:$DIR/../../peakml/bin:$DIR/../lib/*:$DIR/../../peakml/lib/*:/Users/rdaly/work/workspacejeeindigo/MetaSign/build/classes/main:/Users/rdaly/work/workspacejeeindigo/MetaSign/lib/*"


