/* Copyright (C) 2008, Groningen Bioinformatics Centre (http://gbic.biol.rug.nl/)
 * This file is part of PeakML.
 * 
 * PeakML is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation; either version 2.1 of the License, or
 * (at your option) any later version.
 * 
 * PeakML is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with PeakML; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */




// java native interface
#include <jni.h>

// windows
#include <comutil.h>
#include <atlbase.h>

// generated functions
#include "peakml_io_dac_DACHeader.h"
#include "peakml_io_dac_DACCalibrationInfo.h"
#include "peakml_io_dac_DACExperimentInfo.h"
#include "peakml_io_dac_DACFunctionInfo.h"
#include "peakml_io_dac_DACSpectrum.h"
#include "peakml_io_dac_DACScanStats.h"
#include "peakml_io_dac_DACExScanStats.h"
#include "peakml_io_dac_DACProcessInfo.h"


// This is unfortunate. We must find a way of finding the dll automatically.
#import "C:\MassLynx\DACServer.dll" no_namespace named_guids





// implementation
JNIEXPORT jint JNICALL Java_peakml_io_dac_DACHeader_open(JNIEnv *env, jobject obj, jstring filename)
{
	// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACHeaderPtr pHeader = IDACHeaderPtr(CLSID_DACHeader);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));

		// fill the header pointer with the values from the file
		rtcode = pHeader->GetHeader(bstr_filename.Detach());
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;
		
		// retrieve 'AcquDate'
		fieldid = env->GetFieldID(cls, "AcquDate", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR AcquDate = pHeader->GetAcquDate();
			char *lpszAcquDate = _com_util::ConvertBSTRToString(AcquDate);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszAcquDate));
			SysFreeString(AcquDate);
			delete[] lpszAcquDate;
		}
		
		// retrieve 'AcquName'
		fieldid = env->GetFieldID(cls, "AcquName", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR AcquName = pHeader->GetAcquName();
			char *lpszAcquName = _com_util::ConvertBSTRToString(AcquName);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszAcquName));
			SysFreeString(AcquName);
			delete[] lpszAcquName;
		}
		
		// retrieve 'AcquTime'
		fieldid = env->GetFieldID(cls, "AcquTime", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR AcquTime = pHeader->GetAcquTime();
			char *lpszAcquTime = _com_util::ConvertBSTRToString(AcquTime);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszAcquTime));
			SysFreeString(AcquTime);
			delete[] lpszAcquTime;
		}

		// retrieve 'AnalogOffset'
		fieldid = env->GetFieldID(cls, "AnalogOffset", "[I");
		if (fieldid != NULL)
		{
			VARIANT AnalogOffset;
			pHeader->get_AnalogOffset(&AnalogOffset);
			
			long lbound, hbound;
			int HUGEP *pAnalogOffset;
			SafeArrayAccessData(AnalogOffset.parray, (void HUGEP**) &pAnalogOffset);
			SafeArrayGetLBound(AnalogOffset.parray, 1, &lbound);
			SafeArrayGetUBound(AnalogOffset.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jintArray JAnalogOffset = env->NewIntArray(length);
			jint *iAnalogOffset = new jint[length];
			for (int i=0; i<length; ++i)
				iAnalogOffset[i] = pAnalogOffset[i];
			env->SetIntArrayRegion(JAnalogOffset, 0, length, iAnalogOffset);
			env->SetObjectField(obj, fieldid, JAnalogOffset);

			delete[] iAnalogOffset;
			SafeArrayUnaccessData(AnalogOffset.parray);
			SafeArrayDestroyData(AnalogOffset.parray);
		}

		// retrieve 'AutosamplerType'
		fieldid = env->GetFieldID(cls, "AutosamplerType", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pHeader->GetAutosamplerType());
		}
		
		// retrieve 'BottleNumber'
		fieldid = env->GetFieldID(cls, "BottleNumber", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR BottleNumber = pHeader->GetBottleNumber();
			char *lpszBottleNumber = _com_util::ConvertBSTRToString(BottleNumber);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszBottleNumber));
			SysFreeString(BottleNumber);
			delete[] lpszBottleNumber;
		}
		
		// retrieve 'Conditions'
		fieldid = env->GetFieldID(cls, "Conditions", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR Conditions = pHeader->GetConditions();
			char *lpszConditions = _com_util::ConvertBSTRToString(Conditions);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszConditions));
			SysFreeString(Conditions);
			delete[] lpszConditions;
		}

		// retrieve 'Encrypted'
		fieldid = env->GetFieldID(cls, "Encrypted", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pHeader->GetEncrypted());
		}
		
		// retrieve 'GasName'
		fieldid = env->GetFieldID(cls, "GasName", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR GasName = pHeader->GetGasName();
			char *lpszGasName = _com_util::ConvertBSTRToString(GasName);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszGasName));
			SysFreeString(GasName);
			delete[] lpszGasName;
		}
		
		// retrieve 'Instrument'
		fieldid = env->GetFieldID(cls, "Instrument", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR Instrument = pHeader->GetInstrument();
			char *lpszInstrument = _com_util::ConvertBSTRToString(Instrument);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszInstrument));
			SysFreeString(Instrument);
			delete[] lpszInstrument;
		}
		
		// retrieve 'InstrumentType'
		fieldid = env->GetFieldID(cls, "InstrumentType", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR InstrumentType = pHeader->GetInstrumentType();
			char *lpszInstrumentType = _com_util::ConvertBSTRToString(InstrumentType);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszInstrumentType));
			SysFreeString(InstrumentType);
			delete[] lpszInstrumentType;
		}
		
		// retrieve 'JobCode'
		fieldid = env->GetFieldID(cls, "JobCode", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR JobCode = pHeader->GetJobCode();
			char *lpszJobCode = _com_util::ConvertBSTRToString(JobCode);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszJobCode));
			SysFreeString(JobCode);
			delete[] lpszJobCode;
		}
		
		// retrieve 'LabName'
		fieldid = env->GetFieldID(cls, "LabName", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR LabName = pHeader->GetLabName();
			char *lpszLabName = _com_util::ConvertBSTRToString(LabName);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszLabName));
			SysFreeString(LabName);
			delete[] lpszLabName;
		}

		// retrieve 'MuxStream'
		fieldid = env->GetFieldID(cls, "MuxStream", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pHeader->GetMuxStream());
		}
		
		// retrieve 'PepFileName'
		fieldid = env->GetFieldID(cls, "PepFileName", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR PepFileName = pHeader->GetPepFileName();
			char *lpszPepFileName = _com_util::ConvertBSTRToString(PepFileName);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszPepFileName));
			SysFreeString(PepFileName);
			delete[] lpszPepFileName;
		}
		
		// retrieve 'PlateDesc'
		fieldid = env->GetFieldID(cls, "PlateDesc", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR PlateDesc = pHeader->GetPlateDesc();
			char *lpszPlateDesc = _com_util::ConvertBSTRToString(PlateDesc);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszPlateDesc));
			SysFreeString(PlateDesc);
			delete[] lpszPlateDesc;
		}
		
		// retrieve 'Process'
		fieldid = env->GetFieldID(cls, "Process", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR Process = pHeader->GetProcess();
			char *lpszProcess = _com_util::ConvertBSTRToString(Process);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszProcess));
			SysFreeString(Process);
			delete[] lpszProcess;
		}

		// retrieve 'Resolved'
		fieldid = env->GetFieldID(cls, "Resolved", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pHeader->GetResolved());
		}
		
		// retrieve 'SampleDesc'
		fieldid = env->GetFieldID(cls, "SampleDesc", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR SampleDesc = pHeader->GetSampleDesc();
			char *lpszSampleDesc = _com_util::ConvertBSTRToString(SampleDesc);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszSampleDesc));
			SysFreeString(SampleDesc);
			delete[] lpszSampleDesc;
		}
		
		// retrieve 'SampleID'
		fieldid = env->GetFieldID(cls, "SampleID", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR SampleID = pHeader->GetSampleID();
			char *lpszSampleID = _com_util::ConvertBSTRToString(SampleID);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszSampleID));
			SysFreeString(SampleID);
			delete[] lpszSampleID;
		}

		// retrieve 'SolventDelay'
		fieldid = env->GetFieldID(cls, "SolventDelay", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pHeader->GetSolventDelay());
		}
		
		// retrieve 'Submitter'
		fieldid = env->GetFieldID(cls, "Submitter", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR Submitter = pHeader->GetSubmitter();
			char *lpszSubmitter = _com_util::ConvertBSTRToString(Submitter);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszSubmitter));
			SysFreeString(Submitter);
			delete[] lpszSubmitter;
		}
		
		// retrieve 'TaskCode'
		fieldid = env->GetFieldID(cls, "TaskCode", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR TaskCode = pHeader->GetTaskCode();
			char *lpszTaskCode = _com_util::ConvertBSTRToString(TaskCode);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszTaskCode));
			SysFreeString(TaskCode);
			delete[] lpszTaskCode;
		}
		
		// retrieve 'UserName'
		fieldid = env->GetFieldID(cls, "UserName", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR UserName = pHeader->GetUserName();
			char *lpszUserName = _com_util::ConvertBSTRToString(UserName);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszUserName));
			SysFreeString(UserName);
			delete[] lpszUserName;
		}

		// retrieve 'VersionMajor'
		fieldid = env->GetFieldID(cls, "VersionMajor", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pHeader->GetVersionMajor());
		}

		// retrieve 'VersionMinor'
		fieldid = env->GetFieldID(cls, "VersionMinor", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pHeader->GetVersionMinor());
		}
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACCalibrationInfo_open(JNIEnv *env, jobject obj, jstring filename)
{
	// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACCalibrationInfoPtr pCalibrationInfo = IDACCalibrationInfoPtr(CLSID_DACCalibrationInfo);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));

		// fill the header pointer with the values from the file
		rtcode = pCalibrationInfo->GetCalibration(bstr_filename.Detach());
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;
		
		// retrieve 'MS1DynamicParams'
		fieldid = env->GetFieldID(cls, "MS1DynamicParams", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS1DynamicParams = pCalibrationInfo->GetMS1DynamicParams();
			char *lpszMS1DynamicParams = _com_util::ConvertBSTRToString(MS1DynamicParams);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS1DynamicParams));
			SysFreeString(MS1DynamicParams);
			delete[] lpszMS1DynamicParams;
		}
		
		// retrieve 'MS1FastParams'
		fieldid = env->GetFieldID(cls, "MS1FastParams", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS1FastParams = pCalibrationInfo->GetMS1FastParams();
			char *lpszMS1FastParams = _com_util::ConvertBSTRToString(MS1FastParams);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS1FastParams));
			SysFreeString(MS1FastParams);
			delete[] lpszMS1FastParams;
		}
		
		// retrieve 'MS1StaticFunction'
		fieldid = env->GetFieldID(cls, "MS1StaticFunction", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS1StaticFunction = pCalibrationInfo->GetMS1StaticFunction();
			char *lpszMS1StaticFunction = _com_util::ConvertBSTRToString(MS1StaticFunction);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS1StaticFunction));
			SysFreeString(MS1StaticFunction);
			delete[] lpszMS1StaticFunction;
		}
		
		// retrieve 'MS1StaticParams'
		fieldid = env->GetFieldID(cls, "MS1StaticParams", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS1StaticParams = pCalibrationInfo->GetMS1StaticParams();
			char *lpszMS1StaticParams = _com_util::ConvertBSTRToString(MS1StaticParams);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS1StaticParams));
			SysFreeString(MS1StaticParams);
			delete[] lpszMS1StaticParams;
		}
		
		// retrieve 'MS2DynamicParams'
		fieldid = env->GetFieldID(cls, "MS2DynamicParams", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS2DynamicParams = pCalibrationInfo->GetMS2DynamicParams();
			char *lpszMS2DynamicParams = _com_util::ConvertBSTRToString(MS2DynamicParams);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS2DynamicParams));
			SysFreeString(MS2DynamicParams);
			delete[] lpszMS2DynamicParams;
		}
		
		// retrieve 'MS2FastParams'
		fieldid = env->GetFieldID(cls, "MS2FastParams", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS2FastParams = pCalibrationInfo->GetMS2FastParams();
			char *lpszMS2FastParams = _com_util::ConvertBSTRToString(MS2FastParams);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS2FastParams));
			SysFreeString(MS2FastParams);
			delete[] lpszMS2FastParams;
		}
		
		// retrieve 'MS1StaticFunction'
		fieldid = env->GetFieldID(cls, "MS2StaticFunction", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS2StaticFunction = pCalibrationInfo->GetMS2StaticFunction();
			char *lpszMS2StaticFunction = _com_util::ConvertBSTRToString(MS2StaticFunction);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS2StaticFunction));
			SysFreeString(MS2StaticFunction);
			delete[] lpszMS2StaticFunction;
		}
		
		// retrieve 'MS1StaticParams'
		fieldid = env->GetFieldID(cls, "MS2StaticParams", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR MS2StaticParams = pCalibrationInfo->GetMS2StaticParams();
			char *lpszMS2StaticParams = _com_util::ConvertBSTRToString(MS2StaticParams);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszMS2StaticParams));
			SysFreeString(MS2StaticParams);
			delete[] lpszMS2StaticParams;
		}
		
		// retrieve 'CalTime'
		fieldid = env->GetFieldID(cls, "CalTime", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR CalTime = pCalibrationInfo->GetCalTime();
			char *lpszCalTime = _com_util::ConvertBSTRToString(CalTime);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszCalTime));
			SysFreeString(CalTime);
			delete[] lpszCalTime;
		}
		
		// retrieve 'CalDate'
		fieldid = env->GetFieldID(cls, "CalDate", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR CalDate = pCalibrationInfo->GetCalDate();
			char *lpszCalDate = _com_util::ConvertBSTRToString(CalDate);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszCalDate));
			SysFreeString(CalDate);
			delete[] lpszCalDate;
		}

		// retrieve 'NumCalFunctions'
		fieldid = env->GetFieldID(cls, "NumCalFunctions", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pCalibrationInfo->GetNumCalFunctions());
		}

		// retrieve 'CalFunctions'
		fieldid = env->GetFieldID(cls, "CalFunctions", "[Ljava/lang/String;");
		if (fieldid != NULL)
		{
			VARIANT CalFunctions;
			pCalibrationInfo->get_CalFunctions(&CalFunctions);
			
			long lbound, hbound;
			BSTR HUGEP *pCalFunctions;
			SafeArrayAccessData(CalFunctions.parray, (void HUGEP**) &pCalFunctions);
			SafeArrayGetLBound(CalFunctions.parray, 1, &lbound);
			SafeArrayGetUBound(CalFunctions.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jobjectArray JCalFunctions = env->NewObjectArray(length, env->FindClass("Ljava/lang/String;"), NULL);
			for (int i=0; i<length; ++i)
			{
				char *string = _com_util::ConvertBSTRToString(pCalFunctions[i]);
				env->SetObjectArrayElement(JCalFunctions, i, env->NewStringUTF(string));
				delete[] string;
			}
			env->SetObjectField(obj, fieldid, JCalFunctions);

			SafeArrayUnaccessData(CalFunctions.parray);
			SafeArrayDestroyData(CalFunctions.parray);
		}
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACExperimentInfo_open(JNIEnv *env, jobject obj, jstring filename)
{
	// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACExperimentInfoPtr pExperimentInfo = IDACExperimentInfoPtr(CLSID_DACExperimentInfo);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));

		// fill the header pointer with the values from the file
		rtcode = pExperimentInfo->GetExperimentInfo(bstr_filename.Detach());
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;
		
		// retrieve 'ExperimentText'
		fieldid = env->GetFieldID(cls, "ExperimentText", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR ExperimentText = pExperimentInfo->GetExperimentText();
			char *lpszExperimentText = _com_util::ConvertBSTRToString(ExperimentText);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszExperimentText));
			SysFreeString(ExperimentText);
			delete[] lpszExperimentText;
		}

		// call the init function
		jmethodID methodid = env->GetMethodID(cls, "init", "()V");
		if (methodid != NULL)
			env->CallVoidMethod(obj, methodid);
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACFunctionInfo_open(JNIEnv *env, jobject obj, jstring filename, jint functionnr)
{
	// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACFunctionInfoPtr pFunctionInfo = IDACFunctionInfoPtr(CLSID_DACFunctionInfo);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));

		// fill the header pointer with the values from the file
		rtcode = pFunctionInfo->GetFunctionInfo(bstr_filename.Detach(), (short) functionnr);
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;
		
		// retrieve 'FunctionType'
		fieldid = env->GetFieldID(cls, "FunctionType", "Ljava/lang/String;");
		if (fieldid != NULL)
		{
			BSTR FunctionType = pFunctionInfo->GetFunctionType();
			char *lpszFunctionType = _com_util::ConvertBSTRToString(FunctionType);
			env->SetObjectField(obj, fieldid, env->NewStringUTF(lpszFunctionType));
			SysFreeString(FunctionType);
			delete[] lpszFunctionType;
		}

		// retrieve 'StartRT'
		fieldid = env->GetFieldID(cls, "StartRT", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pFunctionInfo->GetStartRT());
		}

		// retrieve 'EndRT'
		fieldid = env->GetFieldID(cls, "EndRT", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pFunctionInfo->GetEndRT());
		}

		// retrieve 'NumScans'
		fieldid = env->GetFieldID(cls, "NumScans", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pFunctionInfo->GetNumScans());
		}

		// retrieve 'FunctionSetMass'
		fieldid = env->GetFieldID(cls, "FunctionSetMass", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pFunctionInfo->GetFunctionSetMass());
		}

		// retrieve 'NumSegments'
		fieldid = env->GetFieldID(cls, "NumSegments", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pFunctionInfo->GetNumSegments());
		}

		// retrieve 'SIRChannels'
		fieldid = env->GetFieldID(cls, "SIRChannels", "[D");
		if (fieldid != NULL)
		{
			VARIANT SIRChannels;
			pFunctionInfo->get_SIRChannels(&SIRChannels);
			
			long lbound, hbound;
			float HUGEP *pSIRChannels;
			SafeArrayAccessData(SIRChannels.parray, (void HUGEP**) &pSIRChannels);
			SafeArrayGetLBound(SIRChannels.parray, 1, &lbound);
			SafeArrayGetUBound(SIRChannels.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jdoubleArray JSIRChannels = env->NewDoubleArray(length);
			jdouble *dSIRChannels = new jdouble[length];
			for (int i=0; i<length; ++i)
				dSIRChannels[i] = pSIRChannels[i];
			env->SetDoubleArrayRegion(JSIRChannels, 0, length, dSIRChannels);
			env->SetObjectField(obj, fieldid, JSIRChannels);

			delete[] dSIRChannels;
			SafeArrayUnaccessData(SIRChannels.parray);
			SafeArrayDestroyData(SIRChannels.parray);
		}
		
		// retrieve 'MRMParents'
		fieldid = env->GetFieldID(cls, "MRMParents", "[D");
		if (fieldid != NULL)
		{
			VARIANT MRMParents;
			pFunctionInfo->get_MRMParents(&MRMParents);
			
			long lbound, hbound;
			float HUGEP *pMRMParents;
			SafeArrayAccessData(MRMParents.parray, (void HUGEP**) &pMRMParents);
			SafeArrayGetLBound(MRMParents.parray, 1, &lbound);
			SafeArrayGetUBound(MRMParents.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jdoubleArray JMRMParents = env->NewDoubleArray(length);
			jdouble *dMRMParents = new jdouble[length];
			for (int i=0; i<length; ++i)
				dMRMParents[i] = pMRMParents[i];
			env->SetDoubleArrayRegion(JMRMParents, 0, length, dMRMParents);
			env->SetObjectField(obj, fieldid, JMRMParents);

			delete[] dMRMParents;
			SafeArrayUnaccessData(MRMParents.parray);
			SafeArrayDestroyData(MRMParents.parray);
		}
		
		// retrieve 'MRMDaughters'
		fieldid = env->GetFieldID(cls, "MRMDaughters", "[D");
		if (fieldid != NULL)
		{
			VARIANT MRMDaughters;
			pFunctionInfo->get_MRMDaughters(&MRMDaughters);
			
			long lbound, hbound;
			float HUGEP *pMRMDaughters;
			SafeArrayAccessData(MRMDaughters.parray, (void HUGEP**) &pMRMDaughters);
			SafeArrayGetLBound(MRMDaughters.parray, 1, &lbound);
			SafeArrayGetUBound(MRMDaughters.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jdoubleArray JMRMDaughters = env->NewDoubleArray(length);
			jdouble *dMRMDaughters = new jdouble[length];
			for (int i=0; i<length; ++i)
				dMRMDaughters[i] = pMRMDaughters[i];
			env->SetDoubleArrayRegion(JMRMDaughters, 0, length, dMRMDaughters);
			env->SetObjectField(obj, fieldid, JMRMDaughters);

			delete[] dMRMDaughters;
			SafeArrayUnaccessData(MRMDaughters.parray);
			SafeArrayDestroyData(MRMDaughters.parray);
		}
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACFunctionInfo_getNumberOfFunctions(JNIEnv *env, jclass cls, jstring filename)
{
	// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACFunctionInfoPtr pFunctionInfo = IDACFunctionInfoPtr(CLSID_DACFunctionInfo);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));
		
		// fill the header pointer with the values from the file
		rtcode = pFunctionInfo->GetNumFunctions(bstr_filename.Detach());
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACSpectrum_open(JNIEnv *env, jobject obj, jstring filename, jint functionnr, jint processnr, jint scannr)
{
	// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACSpectrumPtr pSpectrum = IDACSpectrumPtr(CLSID_DACSpectrum);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));
		
		// fill the header pointer with the values from the file
		rtcode = pSpectrum->GetSpectrum(bstr_filename.Detach(), (short) functionnr, (short) processnr, scannr);
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;

		// retrieve 'NumPeaks'
		fieldid = env->GetFieldID(cls, "NumPeaks", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pSpectrum->GetNumPeaks());
		}

		// retrieve 'Masses'
		fieldid = env->GetFieldID(cls, "Masses", "[D");
		if (fieldid != NULL)
		{
			VARIANT Masses;
			pSpectrum->get_Masses(&Masses);
			
			long lbound, hbound;
			float HUGEP *pMasses;
			SafeArrayAccessData(Masses.parray, (void HUGEP**) &pMasses);
			SafeArrayGetLBound(Masses.parray, 1, &lbound);
			SafeArrayGetUBound(Masses.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jdoubleArray JMasses = env->NewDoubleArray(length);
			jdouble *dMasses = new jdouble[length];
			for (int i=0; i<length; ++i)
				dMasses[i] = pMasses[i];
			env->SetDoubleArrayRegion(JMasses, 0, length, dMasses);
			env->SetObjectField(obj, fieldid, JMasses);

			delete[] dMasses;
			SafeArrayUnaccessData(Masses.parray);
			SafeArrayDestroyData(Masses.parray);
		}

		// retrieve 'Intensities'
		fieldid = env->GetFieldID(cls, "Intensities", "[D");
		if (fieldid != NULL)
		{
			VARIANT Intensities;
			pSpectrum->get_Intensities(&Intensities);
			
			long lbound, hbound;
			float HUGEP *pIntensities;
			SafeArrayAccessData(Intensities.parray, (void HUGEP**) &pIntensities);
			SafeArrayGetLBound(Intensities.parray, 1, &lbound);
			SafeArrayGetUBound(Intensities.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jdoubleArray JIntensities = env->NewDoubleArray(length);
			jdouble *dIntensities = new jdouble[length];
			for (int i=0; i<length; ++i)
				dIntensities[i] = pIntensities[i];
			env->SetDoubleArrayRegion(JIntensities, 0, length, dIntensities);
			env->SetObjectField(obj, fieldid, JIntensities);

			delete[] dIntensities;
			SafeArrayUnaccessData(Intensities.parray);
			SafeArrayDestroyData(Intensities.parray);
		}
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACScanStats_open(JNIEnv *env, jobject obj, jstring filename, jint functionnr, jint processnr, jint scannr)
{
// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACScanStatsPtr pScanStats = IDACScanStatsPtr(CLSID_DACScanStats);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));
		
		// fill the header pointer with the values from the file
		rtcode = pScanStats->GetScanStats(bstr_filename.Detach(), (short) functionnr, (short) processnr, scannr);
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;

		// retrieve 'AccurateMass'
		fieldid = env->GetFieldID(cls, "AccurateMass", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pScanStats->GetAccurateMass());
		}

		// retrieve 'BPI'
		fieldid = env->GetFieldID(cls, "BPI", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pScanStats->GetBPI());
		}

		// retrieve 'BPM'
		fieldid = env->GetFieldID(cls, "BPM", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pScanStats->GetBPM());
		}

		// retrieve 'Calibrated'
		fieldid = env->GetFieldID(cls, "Calibrated", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pScanStats->GetCalibrated());
		}

		// retrieve 'Continuum'
		fieldid = env->GetFieldID(cls, "Continuum", "Z");
		if (fieldid != NULL)
		{
			env->SetBooleanField(obj, fieldid, pScanStats->GetContinuum()!=0);
		}

		// retrieve 'HiMass'
		fieldid = env->GetFieldID(cls, "HiMass", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pScanStats->GetHiMass());
		}

		// retrieve 'LoMass'
		fieldid = env->GetFieldID(cls, "LoMass", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pScanStats->GetLoMass());
		}

		// retrieve 'MolecularMass'
		fieldid = env->GetFieldID(cls, "MolecularMass", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pScanStats->GetMolecularMass());
		}

		// retrieve 'Overload'
		fieldid = env->GetFieldID(cls, "Overload", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pScanStats->GetOverload());
		}

		// retrieve 'PeaksInScan'
		fieldid = env->GetFieldID(cls, "PeaksInScan", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pScanStats->GetPeaksInScan());
		}

		// retrieve 'RetnTime'
		fieldid = env->GetFieldID(cls, "RetnTime", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pScanStats->GetRetnTime());
		}

		// retrieve 'Segment'
		fieldid = env->GetFieldID(cls, "Segment", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pScanStats->GetSegment());
		}

		// retrieve 'TIC'
		fieldid = env->GetFieldID(cls, "TIC", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pScanStats->GetTIC());
		}
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACExScanStats_open(JNIEnv *env, jobject obj, jstring filename, jint functionnr, jint processnr, jint scannr)
{
// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACExScanStatsPtr pExScanStats = IDACExScanStatsPtr(CLSID_DACExScanStats);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));
		
		// fill the header pointer with the values from the file
		rtcode = pExScanStats->GetExScanStats(bstr_filename.Detach(), (short) functionnr, (short) processnr, scannr);
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;

		// retrieve 'AccurateMass'
		fieldid = env->GetFieldID(cls, "AccurateMass", "Z");
		if (fieldid != NULL)
		{
			env->SetBooleanField(obj, fieldid, pExScanStats->GetAccurateMass()!=0);
		}

		// retrieve 'AccurateMass'
		fieldid = env->GetFieldID(cls, "AccurateMassFlags", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetAccurateMassFlags());
		}

		// retrieve 'AccVoltage'
		fieldid = env->GetFieldID(cls, "AccVoltage", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetAccVoltage());
		}

		// retrieve 'CoarseLaserControl'
		fieldid = env->GetFieldID(cls, "CoarseLaserControl", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetCoarseLaserControl());
		}

		// retrieve 'CollisionEnergy'
		fieldid = env->GetFieldID(cls, "CollisionEnergy", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetCollisionEnergy());
		}

		// retrieve 'CollisionRF'
		fieldid = env->GetFieldID(cls, "CollisionRF", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetCollisionRF());
		}

		// retrieve 'CounterElectrodeVoltage'
		fieldid = env->GetFieldID(cls, "CounterElectrodeVoltage", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetCounterElectrodeVoltage());
		}

		// retrieve 'Entrance'
		fieldid = env->GetFieldID(cls, "Entrance", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetEntrance());
		}

		// retrieve 'FaimsCV'
		fieldid = env->GetFieldID(cls, "FaimsCV", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetFaimsCV());
		}

		// retrieve 'FineLaserControl'
		fieldid = env->GetFieldID(cls, "FineLaserControl", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetFineLaserControl());
		}

		// retrieve 'Focus'
		fieldid = env->GetFieldID(cls, "Focus", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetFocus());
		}

		// retrieve 'Guard'
		fieldid = env->GetFieldID(cls, "Guard", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetGuard());
		}

		// retrieve 'HMResolution'
		fieldid = env->GetFieldID(cls, "HMResolution", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetHMResolution());
		}

		// retrieve 'IonEnergy'
		fieldid = env->GetFieldID(cls, "IonEnergy", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetIonEnergy());
		}

		// retrieve 'LaserAimXPos'
		fieldid = env->GetFieldID(cls, "LaserAimXPos", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetLaserAimXPos());
		}

		// retrieve 'LaserAimYPos'
		fieldid = env->GetFieldID(cls, "LaserAimYPos", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetLaserAimYPos());
		}

		// retrieve 'LaserRepetitionRate'
		fieldid = env->GetFieldID(cls, "LaserRepetitionRate", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetLaserRepetitionRate());
		}

		// retrieve 'LinearDetectorVoltage'
		fieldid = env->GetFieldID(cls, "LinearDetectorVoltage", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetLinearDetectorVoltage());
		}

		// retrieve 'LinearSensitivity'
		fieldid = env->GetFieldID(cls, "LinearSensitivity", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetLinearSensitivity());
		}

		// retrieve 'LMResolution'
		fieldid = env->GetFieldID(cls, "LMResolution", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetLMResolution());
		}

		// retrieve 'LockMassCorrection'
		fieldid = env->GetFieldID(cls, "LockMassCorrection", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetLockMassCorrection());
		}

		// retrieve 'Multiplier1'
		fieldid = env->GetFieldID(cls, "Multiplier1", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetMultiplier1());
		}

		// retrieve 'Multiplier2'
		fieldid = env->GetFieldID(cls, "Multiplier2", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetMultiplier2());
		}

		// retrieve 'Needle'
		fieldid = env->GetFieldID(cls, "Needle", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetNeedle());
		}

		// retrieve 'NumShotsPerformed'
		fieldid = env->GetFieldID(cls, "NumShotsPerformed", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetNumShotsPerformed());
		}

		// retrieve 'NumShotsSummed'
		fieldid = env->GetFieldID(cls, "NumShotsSummed", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetNumShotsSummed());
		}

		// retrieve 'ProbeTemperature'
		fieldid = env->GetFieldID(cls, "ProbeTemperature", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetProbeTemperature());
		}

		// retrieve 'PSDFactor1'
		fieldid = env->GetFieldID(cls, "PSDFactor1", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetPSDFactor1());
		}

		// retrieve 'PSDMajorStep'
		fieldid = env->GetFieldID(cls, "PSDMajorStep", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetPSDMajorStep());
		}

		// retrieve 'PSDMinorStep'
		fieldid = env->GetFieldID(cls, "PSDMinorStep", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetPSDMinorStep());
		}

		// retrieve 'PSDSegmentType'
		fieldid = env->GetFieldID(cls, "PSDSegmentType", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetPSDSegmentType());
		}

		// retrieve 'ReferenceScan'
		fieldid = env->GetFieldID(cls, "ReferenceScan", "B");
		if (fieldid != NULL)
		{
			env->SetByteField(obj, fieldid, pExScanStats->GetReferenceScan());
		}

		// retrieve 'Reflectron'
		fieldid = env->GetFieldID(cls, "Reflectron", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetReflectron());
		}

		// retrieve 'ReflectronDetectorVoltage'
		fieldid = env->GetFieldID(cls, "ReflectronDetectorVoltage", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetReflectronDetectorVoltage());
		}

		// retrieve 'ReflectronFieldLength'
		fieldid = env->GetFieldID(cls, "ReflectronFieldLength", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetReflectronFieldLength());
		}

		// retrieve 'ReflectronFieldLengthAlt'
		fieldid = env->GetFieldID(cls, "ReflectronFieldLengthAlt", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetReflectronFieldLengthAlt());
		}

		// retrieve 'ReflectronLength'
		fieldid = env->GetFieldID(cls, "ReflectronLength", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetReflectronLength());
		}

		// retrieve 'ReflectronLengthAlt'
		fieldid = env->GetFieldID(cls, "ReflectronLengthAlt", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetReflectronLengthAlt());
		}

		// retrieve 'ReflectronLensVoltage'
		fieldid = env->GetFieldID(cls, "ReflectronLensVoltage", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetReflectronLensVoltage());
		}

		// retrieve 'ReflectronSensitivity'
		fieldid = env->GetFieldID(cls, "ReflectronSensitivity", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetReflectronSensitivity());
		}

		// retrieve 'ReflectronVoltage'
		fieldid = env->GetFieldID(cls, "ReflectronVoltage", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetReflectronVoltage());
		}

		// retrieve 'RFVoltage'
		fieldid = env->GetFieldID(cls, "RFVoltage", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetRFVoltage());
		}

		// retrieve 'SamplePlateVoltage'
		fieldid = env->GetFieldID(cls, "SamplePlateVoltage", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetSamplePlateVoltage());
		}

		// retrieve 'SamplingConeVoltage'
		fieldid = env->GetFieldID(cls, "SamplingConeVoltage", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSamplingConeVoltage());
		}

		// retrieve 'SegmentNumber'
		fieldid = env->GetFieldID(cls, "SegmentNumber", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSegmentNumber());
		}

		// retrieve 'SetMass'
		fieldid = env->GetFieldID(cls, "SetMass", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetSetMass());
		}

		// retrieve 'Skimmer'
		fieldid = env->GetFieldID(cls, "Skimmer", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSkimmer());
		}

		// retrieve 'SkimmerLens'
		fieldid = env->GetFieldID(cls, "SkimmerLens", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSkimmerLens());
		}

		// retrieve 'SourceAperture'
		fieldid = env->GetFieldID(cls, "SourceAperture", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSourceAperture());
		}

		// retrieve 'SourceCode'
		fieldid = env->GetFieldID(cls, "SourceCode", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSourceCode());
		}

		// retrieve 'SourceRegion1'
		fieldid = env->GetFieldID(cls, "SourceRegion1", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetSourceRegion1());
		}

		// retrieve 'SourceRegion2'
		fieldid = env->GetFieldID(cls, "SourceRegion2", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetSourceRegion2());
		}

		// retrieve 'SourceTemperature'
		fieldid = env->GetFieldID(cls, "SourceTemperature", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSourceTemperature());
		}

		// retrieve 'Steering'
		fieldid = env->GetFieldID(cls, "Steering", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetSteering());
		}

		// retrieve 'TempCoefficient'
		fieldid = env->GetFieldID(cls, "TempCoefficient", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetTempCoefficient());
		}

		// retrieve 'TempCorrection'
		fieldid = env->GetFieldID(cls, "TempCorrection", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetTempCorrection());
		}

		// retrieve 'TFMWell'
		fieldid = env->GetFieldID(cls, "TFMWell", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetTFMWell());
		}

		// retrieve 'TIC_A'
		fieldid = env->GetFieldID(cls, "TIC_A", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetTIC_A());
		}

		// retrieve 'TIC_B'
		fieldid = env->GetFieldID(cls, "TIC_B", "D");
		if (fieldid != NULL)
		{
			env->SetDoubleField(obj, fieldid, pExScanStats->GetTIC_B());
		}

		// retrieve 'TOF'
		fieldid = env->GetFieldID(cls, "TOF", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetTOF());
		}

		// retrieve 'TOFAperture'
		fieldid = env->GetFieldID(cls, "TOFAperture", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetTOFAperture());
		}

		// retrieve 'TransportDC'
		fieldid = env->GetFieldID(cls, "TransportDC", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetTransportDC());
		}

		// retrieve 'TransportRF'
		fieldid = env->GetFieldID(cls, "TransportRF", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pExScanStats->GetTransportRF());
		}

		// retrieve 'UseLockMassCorrection'
		fieldid = env->GetFieldID(cls, "UseLockMassCorrection", "B");
		if (fieldid != NULL)
		{
			env->SetByteField(obj, fieldid, pExScanStats->GetUseLockMassCorrection());
		}

		// retrieve 'UseTempCorrection'
		fieldid = env->GetFieldID(cls, "UseTempCorrection", "B");
		if (fieldid != NULL)
		{
			env->SetByteField(obj, fieldid, pExScanStats->GetUseTempCorrection());
		}
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

JNIEXPORT jint JNICALL Java_peakml_io_dac_DACProcessInfo_open(JNIEnv *env, jobject obj, jstring filename, jint functionnr)
{
	// initialize the com-environment
	CoInitialize(NULL);
	
	// start processing
	int rtcode = 1;
	{
		// retrieve the DACHeader class
		IDACProcessInfoPtr pProcessInfo = IDACProcessInfoPtr(CLSID_DACProcessInfo);

		// setup the parameters
		CComBSTR bstr_filename(env->GetStringUTFChars(filename, NULL));
		
		// fill the header pointer with the values from the file
		rtcode = pProcessInfo->GetProcessInfo(bstr_filename.Detach(), (short) functionnr);
		
		// retrieve the class
		jclass cls = env->GetObjectClass(obj);
		jfieldID fieldid = NULL;

		// retrieve 'NumProcesses'
		fieldid = env->GetFieldID(cls, "NumProcesses", "I");
		if (fieldid != NULL)
		{
			env->SetIntField(obj, fieldid, pProcessInfo->GetNumProcesses());
		}

		// retrieve 'ProcessDescs'
		fieldid = env->GetFieldID(cls, "ProcessDescs", "[Ljava/lang/String;");
		if (fieldid != NULL)
		{
			VARIANT ProcessDescs;
			pProcessInfo->get_ProcessDescs(&ProcessDescs);
			
			long lbound, hbound;
			BSTR HUGEP *pProcessDescs;
			SafeArrayAccessData(ProcessDescs.parray, (void HUGEP**) &pProcessDescs);
			SafeArrayGetLBound(ProcessDescs.parray, 1, &lbound);
			SafeArrayGetUBound(ProcessDescs.parray, 1, &hbound);
			long length = (hbound-lbound) + 1;
			
			jobjectArray JProcessDescs = env->NewObjectArray(length, env->FindClass("Ljava/lang/String;"), NULL);
			for (int i=0; i<length; ++i)
			{
				char *string = _com_util::ConvertBSTRToString(pProcessDescs[i]);
				env->SetObjectArrayElement(JProcessDescs, i, env->NewStringUTF(string));
				delete[] string;
			}
			env->SetObjectField(obj, fieldid, JProcessDescs);

			SafeArrayUnaccessData(ProcessDescs.parray);
			SafeArrayDestroyData(ProcessDescs.parray);
		}
	}

	// let go of the com environment
	CoUninitialize();
	
	// exit gracefully
	return rtcode;
}

